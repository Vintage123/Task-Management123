/**
 * Sample task dataset for seeding the database
 * 100+ tasks with realistic categories, priorities, and time estimates
 */

export interface SampleTask {
  title: string;
  description?: string;
  category: string;
  priority: "low" | "medium" | "high" | "urgent";
  estimatedTime: string;
  estimatedMinutes: number;
}

export const sampleTasks: SampleTask[] = [
  // AI & Automation (15 tasks)
  { title: "Set up OpenAI API integration", category: "AI & Automation", priority: "high", estimatedTime: "3h", estimatedMinutes: 180, description: "Integrate OpenAI GPT-4 API for content generation" },
  { title: "Build chatbot response handler", category: "AI & Automation", priority: "high", estimatedTime: "4h", estimatedMinutes: 240 },
  { title: "Create automation workflow for email", category: "AI & Automation", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Set up scheduled task runner", category: "AI & Automation", priority: "medium", estimatedTime: "1.5h", estimatedMinutes: 90 },
  { title: "Implement ML model training pipeline", category: "AI & Automation", priority: "high", estimatedTime: "8h", estimatedMinutes: 480 },
  { title: "Create data preprocessing script", category: "AI & Automation", priority: "medium", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Build sentiment analysis tool", category: "AI & Automation", priority: "low", estimatedTime: "5h", estimatedMinutes: 300 },
  { title: "Set up monitoring for AI models", category: "AI & Automation", priority: "high", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Create prompt templates library", category: "AI & Automation", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Implement caching for API calls", category: "AI & Automation", priority: "medium", estimatedTime: "1.5h", estimatedMinutes: 90 },
  { title: "Build A/B testing framework", category: "AI & Automation", priority: "low", estimatedTime: "6h", estimatedMinutes: 360 },
  { title: "Create automated report generator", category: "AI & Automation", priority: "medium", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Set up vector database", category: "AI & Automation", priority: "high", estimatedTime: "4h", estimatedMinutes: 240 },
  { title: "Implement RAG system", category: "AI & Automation", priority: "high", estimatedTime: "6h", estimatedMinutes: 360 },
  { title: "Create AI content moderation", category: "AI & Automation", priority: "medium", estimatedTime: "3h", estimatedMinutes: 180 },

  // Data Scraping (12 tasks)
  { title: "Scrape competitor pricing data", category: "Data Scraping", priority: "high", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Build web scraper for product listings", category: "Data Scraping", priority: "high", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Extract data from multiple sources", category: "Data Scraping", priority: "medium", estimatedTime: "4h", estimatedMinutes: 240 },
  { title: "Set up Selenium automation", category: "Data Scraping", priority: "medium", estimatedTime: "2.5h", estimatedMinutes: 150 },
  { title: "Parse JSON API responses", category: "Data Scraping", priority: "low", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Create data validation pipeline", category: "Data Scraping", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Implement proxy rotation", category: "Data Scraping", priority: "high", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Build data deduplication logic", category: "Data Scraping", priority: "medium", estimatedTime: "1.5h", estimatedMinutes: 90 },
  { title: "Create scheduled scraping jobs", category: "Data Scraping", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Set up data storage pipeline", category: "Data Scraping", priority: "high", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Implement error handling for scrapers", category: "Data Scraping", priority: "medium", estimatedTime: "1.5h", estimatedMinutes: 90 },
  { title: "Create data export functionality", category: "Data Scraping", priority: "low", estimatedTime: "1h", estimatedMinutes: 60 },

  // Reselling (10 tasks)
  { title: "List products on Amazon", category: "Reselling", priority: "high", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Optimize eBay listings", category: "Reselling", priority: "high", estimatedTime: "1.5h", estimatedMinutes: 90 },
  { title: "Research supplier pricing", category: "Reselling", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Update inventory spreadsheet", category: "Reselling", priority: "medium", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Process customer orders", category: "Reselling", priority: "high", estimatedTime: "30 min", estimatedMinutes: 30 },
  { title: "Handle returns and refunds", category: "Reselling", priority: "high", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Create product photography", category: "Reselling", priority: "medium", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Write product descriptions", category: "Reselling", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Analyze sales metrics", category: "Reselling", priority: "low", estimatedTime: "1.5h", estimatedMinutes: 90 },
  { title: "Reach out to new suppliers", category: "Reselling", priority: "medium", estimatedTime: "1h", estimatedMinutes: 60 },

  // App Dev (18 tasks)
  { title: "Design database schema", category: "App Dev", priority: "high", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Build REST API endpoints", category: "App Dev", priority: "high", estimatedTime: "5h", estimatedMinutes: 300 },
  { title: "Implement authentication system", category: "App Dev", priority: "high", estimatedTime: "4h", estimatedMinutes: 240 },
  { title: "Create React components", category: "App Dev", priority: "high", estimatedTime: "6h", estimatedMinutes: 360 },
  { title: "Set up CI/CD pipeline", category: "App Dev", priority: "medium", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Write unit tests", category: "App Dev", priority: "medium", estimatedTime: "4h", estimatedMinutes: 240 },
  { title: "Implement error handling", category: "App Dev", priority: "high", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Optimize database queries", category: "App Dev", priority: "medium", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Build admin dashboard", category: "App Dev", priority: "medium", estimatedTime: "5h", estimatedMinutes: 300 },
  { title: "Create mobile responsive design", category: "App Dev", priority: "high", estimatedTime: "4h", estimatedMinutes: 240 },
  { title: "Set up logging and monitoring", category: "App Dev", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Implement caching strategy", category: "App Dev", priority: "low", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Create API documentation", category: "App Dev", priority: "low", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Build notification system", category: "App Dev", priority: "medium", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Implement search functionality", category: "App Dev", priority: "medium", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Set up environment variables", category: "App Dev", priority: "low", estimatedTime: "30 min", estimatedMinutes: 30 },
  { title: "Create deployment script", category: "App Dev", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Fix critical bugs", category: "App Dev", priority: "urgent", estimatedTime: "2h", estimatedMinutes: 120 },

  // Learning (14 tasks)
  { title: "Complete TypeScript course", category: "Learning", priority: "medium", estimatedTime: "20h", estimatedMinutes: 1200 },
  { title: "Learn GraphQL basics", category: "Learning", priority: "low", estimatedTime: "10h", estimatedMinutes: 600 },
  { title: "Study machine learning fundamentals", category: "Learning", priority: "medium", estimatedTime: "15h", estimatedMinutes: 900 },
  { title: "Read React documentation", category: "Learning", priority: "low", estimatedTime: "5h", estimatedMinutes: 300 },
  { title: "Watch Docker tutorials", category: "Learning", priority: "medium", estimatedTime: "8h", estimatedMinutes: 480 },
  { title: "Learn Kubernetes basics", category: "Learning", priority: "low", estimatedTime: "12h", estimatedMinutes: 720 },
  { title: "Study AWS services", category: "Learning", priority: "medium", estimatedTime: "10h", estimatedMinutes: 600 },
  { title: "Complete SQL optimization course", category: "Learning", priority: "medium", estimatedTime: "8h", estimatedMinutes: 480 },
  { title: "Learn Next.js framework", category: "Learning", priority: "low", estimatedTime: "10h", estimatedMinutes: 600 },
  { title: "Study system design patterns", category: "Learning", priority: "medium", estimatedTime: "12h", estimatedMinutes: 720 },
  { title: "Read clean code book", category: "Learning", priority: "low", estimatedTime: "6h", estimatedMinutes: 360 },
  { title: "Learn DevOps practices", category: "Learning", priority: "low", estimatedTime: "15h", estimatedMinutes: 900 },
  { title: "Study cybersecurity fundamentals", category: "Learning", priority: "medium", estimatedTime: "10h", estimatedMinutes: 600 },
  { title: "Complete advanced Python course", category: "Learning", priority: "low", estimatedTime: "12h", estimatedMinutes: 720 },

  // Health (10 tasks)
  { title: "Schedule doctor appointment", category: "Health", priority: "high", estimatedTime: "30 min", estimatedMinutes: 30 },
  { title: "Complete fitness routine", category: "Health", priority: "medium", estimatedTime: "1h", estimatedMinutes: 60, description: "Daily 1-hour workout" },
  { title: "Meal prep for the week", category: "Health", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Take vitamins and supplements", category: "Health", priority: "low", estimatedTime: "10 min", estimatedMinutes: 10 },
  { title: "Meditate daily", category: "Health", priority: "medium", estimatedTime: "30 min/day", estimatedMinutes: 30 },
  { title: "Get dental checkup", category: "Health", priority: "medium", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Review health insurance", category: "Health", priority: "low", estimatedTime: "1.5h", estimatedMinutes: 90 },
  { title: "Start new exercise program", category: "Health", priority: "medium", estimatedTime: "Ongoing", estimatedMinutes: 0 },
  { title: "Track sleep patterns", category: "Health", priority: "low", estimatedTime: "Ongoing", estimatedMinutes: 0 },
  { title: "Reduce caffeine intake", category: "Health", priority: "low", estimatedTime: "Ongoing", estimatedMinutes: 0 },

  // Organization (12 tasks)
  { title: "Clean home office", category: "Organization", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Organize file system", category: "Organization", priority: "medium", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Create project folders", category: "Organization", priority: "low", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Backup important files", category: "Organization", priority: "high", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Review and archive old projects", category: "Organization", priority: "low", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Set up password manager", category: "Organization", priority: "high", estimatedTime: "1.5h", estimatedMinutes: 90 },
  { title: "Create project documentation", category: "Organization", priority: "medium", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Organize bookmarks", category: "Organization", priority: "low", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Set up email filters", category: "Organization", priority: "medium", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Create backup strategy", category: "Organization", priority: "high", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Clean up downloads folder", category: "Organization", priority: "low", estimatedTime: "30 min", estimatedMinutes: 30 },
  { title: "Organize browser extensions", category: "Organization", priority: "low", estimatedTime: "30 min", estimatedMinutes: 30 },

  // Shopping (8 tasks)
  { title: "Buy office supplies", category: "Shopping", priority: "medium", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Purchase new laptop", category: "Shopping", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Order groceries online", category: "Shopping", priority: "low", estimatedTime: "30 min", estimatedMinutes: 30 },
  { title: "Buy birthday gifts", category: "Shopping", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Purchase software licenses", category: "Shopping", priority: "medium", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Buy home furniture", category: "Shopping", priority: "low", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Order tech gadgets", category: "Shopping", priority: "low", estimatedTime: "1.5h", estimatedMinutes: 90 },
  { title: "Purchase fitness equipment", category: "Shopping", priority: "low", estimatedTime: "1h", estimatedMinutes: 60 },

  // Travel (8 tasks)
  { title: "Book flight tickets", category: "Travel", priority: "high", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Reserve hotel accommodation", category: "Travel", priority: "high", estimatedTime: "1.5h", estimatedMinutes: 90 },
  { title: "Plan trip itinerary", category: "Travel", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Get travel insurance", category: "Travel", priority: "medium", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Apply for visa", category: "Travel", priority: "high", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Pack luggage", category: "Travel", priority: "medium", estimatedTime: "1.5h", estimatedMinutes: 90 },
  { title: "Arrange airport transportation", category: "Travel", priority: "medium", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Research travel destinations", category: "Travel", priority: "low", estimatedTime: "3h", estimatedMinutes: 180 },

  // Miscellaneous (15 tasks)
  { title: "Write blog post", category: "Miscellaneous", priority: "medium", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Update resume", category: "Miscellaneous", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Respond to emails", category: "Miscellaneous", priority: "high", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Attend team meeting", category: "Miscellaneous", priority: "high", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Review pull requests", category: "Miscellaneous", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Update project status", category: "Miscellaneous", priority: "medium", estimatedTime: "30 min", estimatedMinutes: 30 },
  { title: "Create presentation slides", category: "Miscellaneous", priority: "medium", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Record demo video", category: "Miscellaneous", priority: "low", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Conduct code review", category: "Miscellaneous", priority: "medium", estimatedTime: "1.5h", estimatedMinutes: 90 },
  { title: "Update documentation", category: "Miscellaneous", priority: "medium", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Plan next sprint", category: "Miscellaneous", priority: "high", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Retrospective meeting", category: "Miscellaneous", priority: "medium", estimatedTime: "1h", estimatedMinutes: 60 },
  { title: "Network with peers", category: "Miscellaneous", priority: "low", estimatedTime: "2h", estimatedMinutes: 120 },
  { title: "Contribute to open source", category: "Miscellaneous", priority: "low", estimatedTime: "3h", estimatedMinutes: 180 },
  { title: "Volunteer for community project", category: "Miscellaneous", priority: "low", estimatedTime: "4h", estimatedMinutes: 240 },
];
