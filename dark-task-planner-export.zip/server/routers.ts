import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  bulkCreateTasks,
  createFile,
  createIdea,
  createTask,
  deleteDrawing,
  deleteFile,
  deleteIdea,
  deleteTask,
  getDrawingsByTask,
  getFilesByTask,
  getIdeaById,
  getIdeasByUser,
  getTaskById,
  getTasksByUser,
  reorderTasks,
  updateIdea,
  updateTask,
  upsertDrawing,
} from "./db";
import { storagePut } from "./storage";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

// ─── Tasks Router ─────────────────────────────────────────────────────────────
const tasksRouter = router({
  list: protectedProcedure
    .input(
      z
        .object({
          search: z.string().optional(),
          status: z.enum(["todo", "in-progress", "done"]).optional(),
          priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
          sortBy: z.enum(["createdAt", "dueDate", "priority", "sortOrder"]).optional(),
          sortDir: z.enum(["asc", "desc"]).optional(),
        })
        .optional()
    )
    .query(async ({ ctx, input }) => {
      return getTasksByUser(ctx.user.id, input);
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const task = await getTaskById(input.id, ctx.user.id);
      if (!task) throw new TRPCError({ code: "NOT_FOUND" });
      return task;
    }),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1).max(512),
        description: z.string().optional(),
        status: z.enum(["todo", "in-progress", "done"]).optional(),
        priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
        dueDate: z.date().optional().nullable(),
        tags: z.array(z.string()).optional(),
        parentId: z.number().optional().nullable(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const id = await createTask({ ...input, userId: ctx.user.id });
      return { id };
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1).max(512).optional(),
        description: z.string().nullable().optional(),
        status: z.enum(["todo", "in-progress", "done"]).optional(),
        priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
        dueDate: z.date().nullable().optional(),
        tags: z.array(z.string()).optional(),
        parentId: z.number().nullable().optional(),
        sortOrder: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await updateTask(id, ctx.user.id, data);
      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await deleteTask(input.id, ctx.user.id);
      return { success: true };
    }),

  // Bulk-update sortOrder for a set of sibling tasks after a drag-drop
  reorder: protectedProcedure
    .input(
      z.object({
        items: z.array(z.object({ id: z.number(), sortOrder: z.number() })),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await reorderTasks(input.items, ctx.user.id);
      return { success: true };
    }),

  // Create many tasks at once from a parsed text file
  bulkCreate: protectedProcedure
    .input(
      z.object({
        titles: z.array(z.string().min(1).max(512)).min(1).max(2000),
        priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
        parentId: z.number().nullable().optional(),
        tags: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const ids = await bulkCreateTasks({
        userId: ctx.user.id,
        titles: input.titles,
        priority: input.priority ?? "medium",
        parentId: input.parentId ?? null,
        tags: input.tags ?? [],
      });
      return { ids, count: ids.length };
    }),
});

// ─── Ideas Router ─────────────────────────────────────────────────────────────
const ideasRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return getIdeasByUser(ctx.user.id);
  }),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1).max(512),
        content: z.string().optional(),
        tags: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const id = await createIdea({ ...input, userId: ctx.user.id });
      return { id };
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1).max(512).optional(),
        content: z.string().nullable().optional(),
        status: z
          .enum(["brainstorm", "refined", "in-progress", "implemented", "archived"])
          .optional(),
        tags: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await updateIdea(id, ctx.user.id, data);
      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await deleteIdea(input.id, ctx.user.id);
      return { success: true };
    }),

  promoteToTask: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1).max(512).optional(),
        description: z.string().optional(),
        priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
        dueDate: z.date().optional().nullable(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const idea = await getIdeaById(input.id, ctx.user.id);
      if (!idea) throw new TRPCError({ code: "NOT_FOUND" });

      const tags = idea.tags ? (JSON.parse(idea.tags) as string[]) : [];
      const taskId = await createTask({
        userId: ctx.user.id,
        title: input.title ?? idea.title,
        description: input.description ?? idea.content ?? undefined,
        status: "todo",
        priority: input.priority ?? "medium",
        dueDate: input.dueDate ?? null,
        tags,
      });

      await updateIdea(input.id, ctx.user.id, {
        status: "implemented",
        convertedTaskId: taskId,
      });

      return { taskId };
    }),
});

// ─── Drawings Router ──────────────────────────────────────────────────────────
const drawingsRouter = router({
  getByTask: protectedProcedure
    .input(z.object({ taskId: z.number() }))
    .query(async ({ ctx, input }) => {
      return getDrawingsByTask(input.taskId, ctx.user.id);
    }),

  upsert: protectedProcedure
    .input(
      z.object({
        id: z.number().optional(),
        taskId: z.number(),
        name: z.string().default("Untitled Canvas"),
        data: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const id = await upsertDrawing({
        id: input.id,
        userId: ctx.user.id,
        taskId: input.taskId,
        name: input.name,
        drawingData: input.data,
      });
      return { id };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await deleteDrawing(input.id, ctx.user.id);
      return { success: true };
    }),
});

// ─── Files Router ─────────────────────────────────────────────────────────────
const filesRouter = router({
  getByTask: protectedProcedure
    .input(z.object({ taskId: z.number() }))
    .query(async ({ ctx, input }) => {
      return getFilesByTask(input.taskId, ctx.user.id);
    }),

  upload: protectedProcedure
    .input(
      z.object({
        taskId: z.number(),
        name: z.string(),
        mimeType: z.string(),
        size: z.number(),
        base64Data: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (input.size > 100 * 1024 * 1024) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "File size exceeds 100MB limit",
        });
      }

      const buffer = Buffer.from(input.base64Data, "base64");
      const key = `user-${ctx.user.id}/tasks/${input.taskId}/${Date.now()}-${input.name}`;

      const { key: storageKey, url: storageUrl } = await storagePut(
        key,
        buffer,
        input.mimeType
      );

      const id = await createFile({
        userId: ctx.user.id,
        taskId: input.taskId,
        name: input.name,
        mimeType: input.mimeType,
        size: input.size,
        storageKey,
        storageUrl,
      });

      return { id, storageUrl };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const file = await deleteFile(input.id, ctx.user.id);
      if (!file) throw new TRPCError({ code: "NOT_FOUND" });
      return { success: true };
    }),
});

// ─── App Router ───────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  tasks: tasksRouter,
  ideas: ideasRouter,
  drawings: drawingsRouter,
  files: filesRouter,
});

export type AppRouter = typeof appRouter;
