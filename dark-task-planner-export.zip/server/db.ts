import { and, asc, desc, eq, isNull, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { drawings, files, ideas, InsertUser, tasks, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;

  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// ─── Tasks ────────────────────────────────────────────────────────────────────
export async function getTasksByUser(
  userId: number,
  opts?: {
    search?: string;
    status?: string;
    priority?: string;
    sortBy?: "createdAt" | "dueDate" | "priority" | "sortOrder";
    sortDir?: "asc" | "desc";
  }
) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [eq(tasks.userId, userId)];

  if (opts?.status) {
    conditions.push(eq(tasks.status, opts.status as "todo" | "in-progress" | "done"));
  }
  if (opts?.priority) {
    conditions.push(
      eq(tasks.priority, opts.priority as "low" | "medium" | "high" | "urgent")
    );
  }
  if (opts?.search) {
    const pattern = `%${opts.search}%`;
    conditions.push(
      or(
        like(tasks.title, pattern),
        like(tasks.description, pattern),
        like(tasks.tags, pattern)
      )!
    );
  }

  const sortDir = opts?.sortDir ?? "desc";
  const sortCol = opts?.sortBy ?? "createdAt";
  const orderFn = sortDir === "asc" ? asc : desc;

  const orderCol =
    sortCol === "dueDate"
      ? tasks.dueDate
      : sortCol === "priority"
      ? tasks.priority
      : sortCol === "sortOrder"
      ? tasks.sortOrder
      : tasks.createdAt;

  return db
    .select()
    .from(tasks)
    .where(and(...conditions))
    .orderBy(orderFn(orderCol));
}

export async function getTaskById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(tasks)
    .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
    .limit(1);
  return result[0];
}

export async function createTask(data: {
  userId: number;
  parentId?: number | null;
  title: string;
  description?: string;
  status?: "todo" | "in-progress" | "done";
  priority?: "low" | "medium" | "high" | "urgent";
  dueDate?: Date | null;
  tags?: string[];
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");

  const tagsJson = data.tags ? JSON.stringify(data.tags) : null;
  const [result] = await db.insert(tasks).values({
    userId: data.userId,
    parentId: data.parentId ?? null,
    title: data.title,
    description: data.description ?? null,
    status: data.status ?? "todo",
    priority: data.priority ?? "medium",
    dueDate: data.dueDate ?? null,
    tags: tagsJson,
    sortOrder: 0,
  });
  return result.insertId as number;
}

export async function updateTask(
  id: number,
  userId: number,
  data: Partial<{
    title: string;
    description: string | null;
    status: "todo" | "in-progress" | "done";
    priority: "low" | "medium" | "high" | "urgent";
    dueDate: Date | null;
    tags: string[];
    parentId: number | null;
    sortOrder: number;
  }>
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");

  const updateData: Record<string, unknown> = { ...data };
  if (data.tags !== undefined) {
    updateData.tags = JSON.stringify(data.tags);
  }

  await db.update(tasks).set(updateData).where(and(eq(tasks.id, id), eq(tasks.userId, userId)));
}

export async function reorderTasks(
  items: { id: number; sortOrder: number }[],
  userId: number
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  // Update each task's sortOrder in parallel
  await Promise.all(
    items.map(({ id, sortOrder }) =>
      db
        .update(tasks)
        .set({ sortOrder })
        .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
    )
  );
}

export async function bulkCreateTasks(data: {
  userId: number;
  titles: string[];
  priority: "low" | "medium" | "high" | "urgent";
  parentId: number | null;
  tags: string[];
}): Promise<number[]> {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");

  const tagsJson = data.tags.length > 0 ? JSON.stringify(data.tags) : null;
  const ids: number[] = [];

  for (let i = 0; i < data.titles.length; i++) {
    const [result] = await db.insert(tasks).values({
      userId: data.userId,
      parentId: data.parentId,
      title: data.titles[i],
      description: null,
      status: "todo",
      priority: data.priority,
      dueDate: null,
      tags: tagsJson,
      sortOrder: i,
    });
    ids.push(result.insertId as number);
  }

  return ids;
}

export async function deleteTask(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  // Also delete children recursively
  const children = await db
    .select({ id: tasks.id })
    .from(tasks)
    .where(and(eq(tasks.parentId, id), eq(tasks.userId, userId)));
  for (const child of children) {
    await deleteTask(child.id, userId);
  }
  await db.delete(tasks).where(and(eq(tasks.id, id), eq(tasks.userId, userId)));
}

// ─── Ideas ────────────────────────────────────────────────────────────────────
export async function getIdeasByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(ideas)
    .where(eq(ideas.userId, userId))
    .orderBy(desc(ideas.createdAt));
}

export async function getIdeaById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(ideas)
    .where(and(eq(ideas.id, id), eq(ideas.userId, userId)))
    .limit(1);
  return result[0];
}

export async function createIdea(data: {
  userId: number;
  title: string;
  content?: string;
  tags?: string[];
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(ideas).values({
    userId: data.userId,
    title: data.title,
    content: data.content ?? null,
    tags: data.tags ? JSON.stringify(data.tags) : null,
    status: "brainstorm",
  });
  return result.insertId as number;
}

export async function updateIdea(
  id: number,
  userId: number,
  data: Partial<{
    title: string;
    content: string | null;
    status: "brainstorm" | "refined" | "in-progress" | "implemented" | "archived";
    tags: string[];
    convertedTaskId: number | null;
  }>
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const updateData: Record<string, unknown> = { ...data };
  if (data.tags !== undefined) {
    updateData.tags = JSON.stringify(data.tags);
  }
  await db.update(ideas).set(updateData).where(and(eq(ideas.id, id), eq(ideas.userId, userId)));
}

export async function deleteIdea(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(ideas).where(and(eq(ideas.id, id), eq(ideas.userId, userId)));
}

// ─── Drawings ─────────────────────────────────────────────────────────────────
export async function getDrawingsByTask(taskId: number, userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(drawings)
    .where(and(eq(drawings.taskId, taskId), eq(drawings.userId, userId)))
    .orderBy(desc(drawings.updatedAt));
}

export async function getDrawingById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(drawings)
    .where(and(eq(drawings.id, id), eq(drawings.userId, userId)))
    .limit(1);
  return result[0];
}

export async function upsertDrawing(data: {
  id?: number;
  userId: number;
  taskId: number;
  name: string;
  drawingData: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");

  if (data.id) {
    await db
      .update(drawings)
      .set({ name: data.name, data: data.drawingData })
      .where(and(eq(drawings.id, data.id), eq(drawings.userId, data.userId)));
    return data.id;
  } else {
    const [result] = await db.insert(drawings).values({
      userId: data.userId,
      taskId: data.taskId,
      name: data.name,
      data: data.drawingData,
    });
    return result.insertId as number;
  }
}

export async function deleteDrawing(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(drawings).where(and(eq(drawings.id, id), eq(drawings.userId, userId)));
}

// ─── Files ────────────────────────────────────────────────────────────────────
export async function getFilesByTask(taskId: number, userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(files)
    .where(and(eq(files.taskId, taskId), eq(files.userId, userId)))
    .orderBy(desc(files.createdAt));
}

export async function createFile(data: {
  userId: number;
  taskId: number;
  name: string;
  mimeType: string;
  size: number;
  storageKey: string;
  storageUrl: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(files).values(data);
  return result.insertId as number;
}

export async function deleteFile(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db
    .select()
    .from(files)
    .where(and(eq(files.id, id), eq(files.userId, userId)))
    .limit(1);
  if (result[0]) {
    await db.delete(files).where(and(eq(files.id, id), eq(files.userId, userId)));
  }
  return result[0];
}
