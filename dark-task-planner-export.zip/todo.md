# Dark Task Planner — TODO

## Phase 1: Setup & Theme
- [x] Install Excalidraw, react-dropzone, and other dependencies
- [x] Set up cyberpunk neon HUD global theme (index.css, fonts, CSS variables)
- [x] Configure dark ThemeProvider in App.tsx

## Phase 2: Database Schema
- [x] Tasks table (id, title, description, status, priority, dueDate, parentId, order, tags, userId)
- [x] Ideas table (id, title, content, status, tags, userId, convertedTaskId)
- [x] Drawings table (id, taskId, data, userId, name)
- [x] Files table (id, taskId, name, mimeType, size, storageKey, storageUrl, userId)
- [x] Generate and apply migrations

## Phase 3: Backend Routers
- [x] tasks router: list, getById, create, update, delete, reorder, bulkCreate
- [x] ideas router: list, create, update, delete, promoteToTask
- [x] drawings router: getByTask, upsert, delete
- [x] files router: getByTask, upload, delete

## Phase 4: Task Management UI
- [x] Sidebar DashboardLayout with cyberpunk styling
- [x] Tasks page with hierarchical tree view
- [x] Task CRUD (create/edit/delete dialogs)
- [x] Subtask nesting (3 levels deep)
- [x] Priority badges (low, medium, high, urgent)
- [x] Status tracking (todo, in-progress, done)
- [x] Due date picker
- [x] Tag support for tasks
- [x] Filter panel (status, priority)
- [x] Sort controls (manual order, priority, due date, created)
- [x] Full-text search across title, description, tags

## Phase 5: Ideas Section
- [x] Ideas page with capture input
- [x] Idea status flow (brainstorm, refined, in-progress, implemented, archived)
- [x] Tag support for ideas
- [x] One-click promote-to-task conversion
- [x] Ideas distinct from task list

## Phase 6: Excalidraw Canvas
- [x] Embed Excalidraw component
- [x] Per-task canvas (linked at individual task level)
- [x] Save/load drawing data to DB
- [x] Open canvas from task detail panel

## Phase 7: File Attachments
- [x] File upload UI (drag-and-drop + click)
- [x] S3 storage via storagePut
- [x] Attach files to individual tasks
- [x] File metadata display (name, size, type, date)
- [x] Image preview in-app
- [x] PDF/document download link

## Phase 8: Polish & Tests
- [x] Cyberpunk neon glow effects on key elements
- [x] HUD corner brackets and thin technical lines
- [x] Smooth transitions and micro-interactions
- [x] Responsive layout (mobile, tablet, desktop)
- [x] Vitest unit tests for all routers
- [x] Empty states for all sections

## Drag-and-Drop Reordering
- [x] Install @dnd-kit/core, @dnd-kit/sortable, @dnd-kit/utilities
- [x] Add tasks.reorder tRPC procedure (bulk-update sortOrder for siblings)
- [x] Wrap task tree nodes in DndContext + SortableContext per sibling group
- [x] Add drag handle to each task row
- [x] Persist new order to DB on drop (optimistic update + server sync)

## Bulk Text Import
- [x] Add tasks.bulkCreate tRPC procedure (array of titles → batch insert)
- [x] Build ImportDialog component with file drop zone
- [x] Parse numbered list from .txt file (strips leading numbers/dots/parens)
- [x] Show parsed preview list before confirming import
- [x] Allow user to set default priority and tags before import
- [x] Import button in Tasks page header
- [x] Vitest tests for reorder and bulkCreate procedures

## Task Progress Bar
- [x] Compute completion % from direct children (done / total) in TasksPage tree
- [x] Render neon progress bar beneath parent task title (only when has children)
- [x] Show percentage label and done/total count next to bar
- [x] Animate bar fill with CSS transition on status change

## Overdue Highlighting
- [x] Add pulsing neon-red border to overdue, non-done task rows
- [x] Add overdue keyframe animation to index.css
- [x] Tint the due-date label red when overdue
- [x] Show "OVERDUE" badge on overdue tasks

## Bug Fixes
- [x] Fix bulk import: 500+ tasks gets stuck on preview — import button not visible/scrollable, and backend rejects >500 items
  - Raised limit from 500 to 2000 items
  - Fixed preview layout: sticky footer with border separator, constrained scroll area
  - Compacted item rows (smaller font, tighter padding) for better density

## Calendar & Categorization System

### Phase 1: Schema & Data Import
- [ ] Add category, priority, estimatedTime, scheduledDate to tasks table
- [ ] Generate and apply schema migration
- [ ] Parse 100+ task list from uploaded file
- [ ] Implement bulk import with category/priority/time assignment
- [ ] Write seed script to populate database

### Phase 2: Backend Routers
- [ ] Calendar queries: getTasksByDateRange, getTasksByDate
- [ ] Category/priority filtering and aggregation
- [ ] Time estimate calculations and rollups
- [ ] Bulk edit operations (change category/priority in batch)
- [ ] Workload summary queries

### Phase 3: Calendar UI
- [ ] Calendar component with month/week/day views
- [ ] Drag-and-drop task scheduling onto dates
- [ ] Priority color coding (High=red, Medium=yellow, Low=blue)
- [ ] Workload indicators per day
- [ ] Task density visualization

### Phase 4: Visualizations
- [ ] Pie chart: task distribution by category
- [ ] Pie chart: task distribution by priority
- [ ] Bar chart: total estimated hours by category
- [ ] Workload summary: task counts by priority per category
- [ ] Real-time updates on task completion

### Phase 5: Task Categorization UI
- [ ] Quick-add form with category/priority/time fields
- [ ] Category filter chips in task list
- [ ] Priority filter chips
- [ ] Bulk edit dialog for multiple tasks
- [ ] Time estimate display and editing

### Phase 6: Integration & Polish
- [ ] Add Calendar and Analytics pages to sidebar
- [ ] Write vitest tests for routers and utilities
- [ ] Responsive design for all new components
- [ ] Performance optimization for 100+ tasks
- [ ] Polish animations and transitions
