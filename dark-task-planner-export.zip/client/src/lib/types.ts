export type TaskStatus = "todo" | "in-progress" | "done";
export type TaskPriority = "low" | "medium" | "high" | "urgent";
export type IdeaStatus = "brainstorm" | "refined" | "in-progress" | "implemented" | "archived";

export interface TaskRow {
  id: number;
  userId: number;
  parentId: number | null;
  title: string;
  description: string | null;
  status: TaskStatus;
  priority: TaskPriority;
  dueDate: Date | null;
  tags: string | null;
  sortOrder: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface IdeaRow {
  id: number;
  userId: number;
  title: string;
  content: string | null;
  status: IdeaStatus;
  tags: string | null;
  convertedTaskId: number | null;
  createdAt: Date;
  updatedAt: Date;
}

export function parseTags(raw: string | null): string[] {
  if (!raw) return [];
  try {
    return JSON.parse(raw) as string[];
  } catch {
    return [];
  }
}

export const STATUS_LABELS: Record<TaskStatus, string> = {
  todo: "Todo",
  "in-progress": "In Progress",
  done: "Done",
};

export const PRIORITY_LABELS: Record<TaskPriority, string> = {
  low: "Low",
  medium: "Medium",
  high: "High",
  urgent: "Urgent",
};

export const IDEA_STATUS_LABELS: Record<IdeaStatus, string> = {
  brainstorm: "Brainstorm",
  refined: "Refined",
  "in-progress": "In Progress",
  implemented: "Implemented",
  archived: "Archived",
};
