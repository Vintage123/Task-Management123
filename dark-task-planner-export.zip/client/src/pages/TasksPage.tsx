import {
  DndContext,
  DragEndEvent,
  DragOverlay,
  DragStartEvent,
  KeyboardSensor,
  PointerSensor,
  closestCenter,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import {
  SortableContext,
  arrayMove,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { trpc } from "@/lib/trpc";
import {
  parseTags,
  PRIORITY_LABELS,
  TaskPriority,
  TaskRow,
  TaskStatus,
} from "@/lib/types";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import {
  AlertCircle,
  Calendar,
  ChevronDown,
  ChevronRight,
  Filter,
  GripVertical,
  Pencil,
  Plus,
  Search,
  Tag,
  Trash2,
  Upload,
  X,
  Zap,
} from "lucide-react";
import { useCallback, useMemo, useState } from "react";
import { toast } from "sonner";
import TaskDialog from "@/components/TaskDialog";
import TaskDetailPanel from "@/components/TaskDetailPanel";
import ImportDialog from "@/components/ImportDialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// ─── Types ────────────────────────────────────────────────────────────────────
type TaskNode = TaskRow & { children: TaskNode[] };

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function TasksPage() {
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<TaskStatus | "all">("all");
  const [filterPriority, setFilterPriority] = useState<TaskPriority | "all">("all");
  const [sortBy, setSortBy] = useState<"createdAt" | "dueDate" | "priority" | "sortOrder">("sortOrder");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const [selectedTaskId, setSelectedTaskId] = useState<number | null>(null);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskRow | null>(null);
  const [importOpen, setImportOpen] = useState(false);
  const [expandedIds, setExpandedIds] = useState<Set<number>>(new Set());
  const [activeId, setActiveId] = useState<number | null>(null);

  const utils = trpc.useUtils();

  const { data: allTasks = [], isLoading } = trpc.tasks.list.useQuery({
    search: search || undefined,
    status: filterStatus !== "all" ? filterStatus : undefined,
    priority: filterPriority !== "all" ? filterPriority : undefined,
    sortBy,
    sortDir,
  });

  const deleteMutation = trpc.tasks.delete.useMutation({
    onSuccess: () => {
      utils.tasks.list.invalidate();
      toast.success("Task deleted");
    },
    onError: () => toast.error("Failed to delete task"),
  });

  const updateMutation = trpc.tasks.update.useMutation({
    onSuccess: () => utils.tasks.list.invalidate(),
    onError: () => toast.error("Failed to update task"),
  });

  const reorderMutation = trpc.tasks.reorder.useMutation({
    onError: () => {
      utils.tasks.list.invalidate();
      toast.error("Failed to save order");
    },
  });

  // Build tree structure
  const taskTree = useMemo(() => buildTree(allTasks), [allTasks]);

  // Flat map for quick lookup
  const taskMap = useMemo(() => {
    const m = new Map<number, TaskRow>();
    for (const t of allTasks) m.set(t.id, t);
    return m;
  }, [allTasks]);

  const toggleExpand = useCallback((id: number) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }, []);

  const handleStatusCycle = (task: TaskRow) => {
    const cycle: TaskStatus[] = ["todo", "in-progress", "done"];
    const next = cycle[(cycle.indexOf(task.status) + 1) % cycle.length];
    updateMutation.mutate({ id: task.id, status: next });
  };

  // dnd-kit sensors
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as number);
  };

  // Called when a drag ends — find the siblings group and reorder within it
  const handleDragEnd = useCallback(
    (event: DragEndEvent) => {
      setActiveId(null);
      const { active, over } = event;
      if (!over || active.id === over.id) return;

      const draggedId = active.id as number;
      const overId = over.id as number;

      const draggedTask = taskMap.get(draggedId);
      const overTask = taskMap.get(overId);
      if (!draggedTask || !overTask) return;

      // Only allow reorder within the same parent
      if (draggedTask.parentId !== overTask.parentId) {
        toast.error("Can only reorder within the same level");
        return;
      }

      // Get siblings (same parentId)
      const parentId = draggedTask.parentId;
      const siblings = allTasks
        .filter((t) => t.parentId === parentId)
        .sort((a, b) => a.sortOrder - b.sortOrder);

      const oldIndex = siblings.findIndex((t) => t.id === draggedId);
      const newIndex = siblings.findIndex((t) => t.id === overId);
      if (oldIndex === -1 || newIndex === -1) return;

      const reordered = arrayMove(siblings, oldIndex, newIndex);
      const items = reordered.map((t, i) => ({ id: t.id, sortOrder: i }));

      // Optimistic update via cache — match the exact active query key
      const queryInput = {
        search: search || undefined,
        status: filterStatus !== "all" ? filterStatus : undefined,
        priority: filterPriority !== "all" ? filterPriority : undefined,
        sortBy,
        sortDir,
      };
      utils.tasks.list.setData(queryInput, (old) => {
        if (!old) return old;
        const updated = old.map((t) => {
          const found = items.find((x) => x.id === t.id);
          return found ? { ...t, sortOrder: found.sortOrder } : t;
        });
        return updated.sort((a, b) => a.sortOrder - b.sortOrder);
      });

      reorderMutation.mutate({ items });
    },
    [allTasks, taskMap, search, filterStatus, filterPriority, sortBy, sortDir, reorderMutation, utils]
  );

  const activeTask = activeId ? taskMap.get(activeId) : null;

  return (
    <div className="flex h-screen overflow-hidden">
      {/* ── Task List ── */}
      <div
        className={cn(
          "flex flex-col transition-all duration-300",
          selectedTaskId ? "w-[55%]" : "w-full"
        )}
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-border flex items-center justify-between gap-4 flex-shrink-0">
          <div>
            <h1 className="font-['Orbitron'] text-lg font-bold neon-cyan tracking-widest uppercase">
              Tasks
            </h1>
            <p className="text-xs font-mono text-muted-foreground mt-0.5">
              {allTasks.length} entries
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              onClick={() => setImportOpen(true)}
              className="border-[oklch(0.65_0.28_330/0.5)] text-[oklch(0.65_0.28_330)] hover:bg-[oklch(0.65_0.28_330/0.1)] btn-neon-pink font-['Rajdhani'] tracking-widest uppercase text-xs h-8"
            >
              <Upload className="w-3.5 h-3.5 mr-1.5" />
              Import
            </Button>
            <Button
              onClick={() => setCreateDialogOpen(true)}
              className="btn-neon-cyan bg-[oklch(0.78_0.22_195/0.1)] border border-[oklch(0.78_0.22_195/0.5)] text-[oklch(0.78_0.22_195)] hover:bg-[oklch(0.78_0.22_195/0.2)] font-['Rajdhani'] tracking-widest uppercase text-xs"
            >
              <Plus className="w-3.5 h-3.5 mr-1.5" />
              New Task
            </Button>
          </div>
        </div>

        {/* Search & Filters */}
        <div className="px-6 py-3 border-b border-border flex items-center gap-3 flex-shrink-0 flex-wrap">
          <div className="relative flex-1 min-w-[160px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search tasks..."
              className="pl-9 bg-input border-border font-mono text-sm h-8 text-foreground placeholder:text-muted-foreground"
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <Select value={filterStatus} onValueChange={(v) => setFilterStatus(v as TaskStatus | "all")}>
            <SelectTrigger className="w-32 h-8 bg-input border-border text-xs font-mono">
              <Filter className="w-3 h-3 mr-1.5 text-muted-foreground" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent className="bg-popover border-border">
              <SelectItem value="all" className="text-xs font-mono">All Status</SelectItem>
              <SelectItem value="todo" className="text-xs font-mono">Todo</SelectItem>
              <SelectItem value="in-progress" className="text-xs font-mono">In Progress</SelectItem>
              <SelectItem value="done" className="text-xs font-mono">Done</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filterPriority} onValueChange={(v) => setFilterPriority(v as TaskPriority | "all")}>
            <SelectTrigger className="w-32 h-8 bg-input border-border text-xs font-mono">
              <AlertCircle className="w-3 h-3 mr-1.5 text-muted-foreground" />
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent className="bg-popover border-border">
              <SelectItem value="all" className="text-xs font-mono">All Priority</SelectItem>
              <SelectItem value="low" className="text-xs font-mono">Low</SelectItem>
              <SelectItem value="medium" className="text-xs font-mono">Medium</SelectItem>
              <SelectItem value="high" className="text-xs font-mono">High</SelectItem>
              <SelectItem value="urgent" className="text-xs font-mono">Urgent</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={`${sortBy}:${sortDir}`}
            onValueChange={(v) => {
              const [col, dir] = v.split(":") as [typeof sortBy, typeof sortDir];
              setSortBy(col);
              setSortDir(dir);
            }}
          >
            <SelectTrigger className="w-36 h-8 bg-input border-border text-xs font-mono">
              <SelectValue placeholder="Sort" />
            </SelectTrigger>
            <SelectContent className="bg-popover border-border">
              <SelectItem value="sortOrder:asc" className="text-xs font-mono">Manual Order</SelectItem>
              <SelectItem value="createdAt:desc" className="text-xs font-mono">Newest First</SelectItem>
              <SelectItem value="createdAt:asc" className="text-xs font-mono">Oldest First</SelectItem>
              <SelectItem value="dueDate:asc" className="text-xs font-mono">Due Date ↑</SelectItem>
              <SelectItem value="dueDate:desc" className="text-xs font-mono">Due Date ↓</SelectItem>
              <SelectItem value="priority:desc" className="text-xs font-mono">Priority ↑</SelectItem>
              <SelectItem value="priority:asc" className="text-xs font-mono">Priority ↓</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Task List */}
        <div className="flex-1 overflow-y-auto px-4 py-3">
          {isLoading ? (
            <div className="flex items-center justify-center h-32">
              <Zap className="w-6 h-6 neon-cyan animate-pulse" />
            </div>
          ) : taskTree.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 gap-3">
              <Zap className="w-8 h-8 text-muted-foreground" />
              <p className="text-sm text-muted-foreground font-mono">No tasks found</p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCreateDialogOpen(true)}
                className="text-xs font-mono border-border"
              >
                Create first task
              </Button>
            </div>
          ) : (
            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragStart={handleDragStart}
              onDragEnd={handleDragEnd}
            >
              <div className="space-y-1">
                <SortableTaskGroup
                  nodes={taskTree}
                  depth={0}
                  expandedIds={expandedIds}
                  onToggle={toggleExpand}
                  selectedId={selectedTaskId}
                  onSelect={setSelectedTaskId}
                  onEdit={setEditingTask}
                  onDelete={(id) => deleteMutation.mutate({ id })}
                  onStatusCycle={handleStatusCycle}
                  onAddSubtask={(parentId) => {
                    setEditingTask(null);
                    setCreateDialogOpen(true);
                    sessionStorage.setItem("newTaskParentId", String(parentId));
                  }}
                  activeId={activeId}
                />
              </div>

              {/* Drag overlay — ghost card */}
              <DragOverlay>
                {activeTask && (
                  <div className="flex items-center gap-2 px-3 py-2.5 bg-card border border-[oklch(0.78_0.22_195/0.6)] shadow-[0_0_20px_oklch(0.78_0.22_195/0.3)] opacity-90 rounded-sm">
                    <GripVertical className="w-3.5 h-3.5 text-[oklch(0.78_0.22_195)]" />
                    <span className="text-sm font-['Rajdhani'] font-semibold text-foreground truncate max-w-xs">
                      {activeTask.title}
                    </span>
                  </div>
                )}
              </DragOverlay>
            </DndContext>
          )}
        </div>
      </div>

      {/* ── Task Detail Panel ── */}
      {selectedTaskId && (
        <div className="flex-1 min-w-0 border-l border-border overflow-hidden">
          <TaskDetailPanel
            taskId={selectedTaskId}
            onClose={() => setSelectedTaskId(null)}
            onEdit={(task) => setEditingTask(task)}
          />
        </div>
      )}

      {/* ── Dialogs ── */}
      <TaskDialog
        open={createDialogOpen || !!editingTask}
        task={editingTask}
        onClose={() => {
          setCreateDialogOpen(false);
          setEditingTask(null);
          sessionStorage.removeItem("newTaskParentId");
        }}
        defaultParentId={
          editingTask
            ? undefined
            : sessionStorage.getItem("newTaskParentId")
            ? Number(sessionStorage.getItem("newTaskParentId"))
            : undefined
        }
      />

      <ImportDialog open={importOpen} onClose={() => setImportOpen(false)} />
    </div>
  );
}

// ─── Build Tree ───────────────────────────────────────────────────────────────
function buildTree(flat: TaskRow[]): TaskNode[] {
  const map = new Map<number, TaskNode>();
  const roots: TaskNode[] = [];
  for (const t of flat) map.set(t.id, { ...t, children: [] });
  for (const t of flat) {
    const node = map.get(t.id)!;
    if (t.parentId && map.has(t.parentId)) {
      map.get(t.parentId)!.children.push(node);
    } else {
      roots.push(node);
    }
  }
  return roots;
}

// ─── Sortable Group (renders a DnD-enabled sibling list) ─────────────────────
function SortableTaskGroup({
  nodes,
  depth,
  expandedIds,
  onToggle,
  selectedId,
  onSelect,
  onEdit,
  onDelete,
  onStatusCycle,
  onAddSubtask,
  activeId,
}: {
  nodes: TaskNode[];
  depth: number;
  expandedIds: Set<number>;
  onToggle: (id: number) => void;
  selectedId: number | null;
  onSelect: (id: number) => void;
  onEdit: (task: TaskRow) => void;
  onDelete: (id: number) => void;
  onStatusCycle: (task: TaskRow) => void;
  onAddSubtask: (parentId: number) => void;
  activeId: number | null;
}) {
  const ids = nodes.map((n) => n.id);

  return (
    <SortableContext items={ids} strategy={verticalListSortingStrategy}>
      {nodes.map((node) => (
        <SortableTaskNode
          key={node.id}
          node={node}
          depth={depth}
          expandedIds={expandedIds}
          onToggle={onToggle}
          selectedId={selectedId}
          onSelect={onSelect}
          onEdit={onEdit}
          onDelete={onDelete}
          onStatusCycle={onStatusCycle}
          onAddSubtask={onAddSubtask}
          activeId={activeId}
          isDragging={activeId === node.id}
        />
      ))}
    </SortableContext>
  );
}

// ─── Sortable Task Node ───────────────────────────────────────────────────────
function SortableTaskNode({
  node,
  depth,
  expandedIds,
  onToggle,
  selectedId,
  onSelect,
  onEdit,
  onDelete,
  onStatusCycle,
  onAddSubtask,
  activeId,
  isDragging,
}: {
  node: TaskNode;
  depth: number;
  expandedIds: Set<number>;
  onToggle: (id: number) => void;
  selectedId: number | null;
  onSelect: (id: number) => void;
  onEdit: (task: TaskRow) => void;
  onDelete: (id: number) => void;
  onStatusCycle: (task: TaskRow) => void;
  onAddSubtask: (parentId: number) => void;
  activeId: number | null;
  isDragging: boolean;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging: isSortableDragging,
  } = useSortable({ id: node.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isSortableDragging ? 0.3 : 1,
  };

  const isExpanded = expandedIds.has(node.id);
  const hasChildren = node.children.length > 0;
  const isSelected = selectedId === node.id;
  const tags = parseTags(node.tags);
  const isOverdue =
    !!node.dueDate &&
    new Date(node.dueDate) < new Date() &&
    node.status !== "done";

  return (
    <div ref={setNodeRef} style={style}>
      <div
        className={cn(
          "group flex items-start gap-2 px-3 py-2.5 rounded-sm border transition-colors duration-150 cursor-pointer",
          // Base background: selected takes priority, then overdue, then default
          isSelected
            ? "bg-[oklch(0.78_0.22_195/0.06)]"
            : isOverdue
            ? "bg-[oklch(0.65_0.28_25/0.04)] hover:bg-[oklch(0.65_0.28_25/0.07)]"
            : "hover:bg-muted/30",
          // Border: overdue pulse always wins over default; selected cyan overrides only when not overdue
          isOverdue
            ? "overdue-row"
            : isSelected
            ? "border-[oklch(0.78_0.22_195/0.4)]"
            : "border-transparent hover:border-border"
        )}
        style={{ marginLeft: `${depth * 20}px` }}
        onClick={() => onSelect(node.id)}
      >
        {/* Drag handle */}
        <button
          className="mt-0.5 flex-shrink-0 w-4 h-4 flex items-center justify-center text-muted-foreground/40 hover:text-[oklch(0.78_0.22_195)] transition-colors cursor-grab active:cursor-grabbing touch-none"
          {...attributes}
          {...listeners}
          onClick={(e) => e.stopPropagation()}
          title="Drag to reorder"
        >
          <GripVertical className="w-3.5 h-3.5" />
        </button>

        {/* Expand toggle */}
        <button
          className="mt-0.5 flex-shrink-0 w-4 h-4 flex items-center justify-center text-muted-foreground hover:text-foreground"
          onClick={(e) => {
            e.stopPropagation();
            if (hasChildren) onToggle(node.id);
          }}
        >
          {hasChildren ? (
            isExpanded ? (
              <ChevronDown className="w-3.5 h-3.5" />
            ) : (
              <ChevronRight className="w-3.5 h-3.5" />
            )
          ) : (
            <span className="w-1 h-1 rounded-full bg-border block" />
          )}
        </button>

        {/* Status badge */}
        <button
          className={cn(
            "flex-shrink-0 mt-0.5 px-1.5 py-0.5 text-[10px] font-mono border rounded-sm tracking-widest uppercase transition-all duration-150",
            node.status === "todo" && "status-todo",
            node.status === "in-progress" && "status-in-progress",
            node.status === "done" && "status-done"
          )}
          onClick={(e) => {
            e.stopPropagation();
            onStatusCycle(node);
          }}
          title="Click to cycle status"
        >
          {node.status === "todo" ? "TODO" : node.status === "in-progress" ? "WIP" : "DONE"}
        </button>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span
              className={cn(
                "text-sm font-semibold font-['Rajdhani'] tracking-wide",
                node.status === "done" ? "line-through text-muted-foreground" : "text-foreground"
              )}
            >
              {node.title}
            </span>
            <PriorityBadge priority={node.priority} />
            {isOverdue && (
              <span className="px-1.5 py-0.5 text-[9px] font-mono border rounded-sm tracking-widest uppercase text-destructive border-destructive/50 bg-destructive/10 animate-pulse">
                OVERDUE
              </span>
            )}
          </div>

          <div className="flex items-center gap-3 mt-1 flex-wrap">
            {node.dueDate && (
              <span
                className={cn(
                  "flex items-center gap-1 text-[10px] font-mono",
                  isOverdue ? "text-destructive font-bold" : "text-muted-foreground"
                )}
              >
                <Calendar className="w-2.5 h-2.5" />
                {format(new Date(node.dueDate), "MMM d")}
              </span>
            )}
            {tags.length > 0 && (
              <span className="flex items-center gap-1 text-[10px] font-mono text-muted-foreground">
                <Tag className="w-2.5 h-2.5" />
                {tags.slice(0, 2).join(", ")}
                {tags.length > 2 && ` +${tags.length - 2}`}
              </span>
            )}
          </div>

          {/* Progress bar — only shown for parent tasks */}
          {hasChildren && (() => {
            const total = node.children.length;
            const done = node.children.filter((c) => c.status === "done").length;
            const pct = total > 0 ? Math.round((done / total) * 100) : 0;
            const allDone = done === total;
            return (
              <div className="mt-1.5 space-y-0.5">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex-1 h-1 bg-muted/60 rounded-full overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-500",
                        allDone
                          ? "bg-[oklch(0.75_0.22_145)] shadow-[0_0_6px_oklch(0.75_0.22_145/0.7)]"
                          : pct > 0
                          ? "bg-[oklch(0.78_0.22_195)] shadow-[0_0_4px_oklch(0.78_0.22_195/0.5)]"
                          : "bg-muted-foreground/30"
                      )}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <span
                    className={cn(
                      "text-[9px] font-mono flex-shrink-0 tabular-nums",
                      allDone ? "text-[oklch(0.75_0.22_145)]" : "text-muted-foreground"
                    )}
                  >
                    {done}/{total} &middot; {pct}%
                  </span>
                </div>
              </div>
            );
          })()}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-150 flex-shrink-0">
          {depth < 2 && (
            <button
              className="p-1 text-muted-foreground hover:text-[oklch(0.78_0.22_195)] transition-colors"
              title="Add subtask"
              onClick={(e) => {
                e.stopPropagation();
                onAddSubtask(node.id);
              }}
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            className="p-1 text-muted-foreground hover:text-[oklch(0.78_0.22_195)] transition-colors"
            title="Edit"
            onClick={(e) => {
              e.stopPropagation();
              onEdit(node);
            }}
          >
            <Pencil className="w-3.5 h-3.5" />
          </button>
          <button
            className="p-1 text-muted-foreground hover:text-destructive transition-colors"
            title="Delete"
            onClick={(e) => {
              e.stopPropagation();
              if (confirm("Delete this task and all its subtasks?")) {
                onDelete(node.id);
              }
            }}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Children — each level gets its own SortableContext */}
      {isExpanded && hasChildren && (
        <SortableTaskGroup
          nodes={node.children}
          depth={depth + 1}
          expandedIds={expandedIds}
          onToggle={onToggle}
          selectedId={selectedId}
          onSelect={onSelect}
          onEdit={onEdit}
          onDelete={onDelete}
          onStatusCycle={onStatusCycle}
          onAddSubtask={onAddSubtask}
          activeId={activeId}
        />
      )}
    </div>
  );
}

// ─── Priority Badge ───────────────────────────────────────────────────────────
export function PriorityBadge({ priority }: { priority: TaskPriority }) {
  return (
    <span
      className={cn(
        "px-1.5 py-0.5 text-[10px] font-mono border rounded-sm tracking-widest uppercase",
        priority === "low" && "priority-low",
        priority === "medium" && "priority-medium",
        priority === "high" && "priority-high",
        priority === "urgent" && "priority-urgent"
      )}
    >
      {PRIORITY_LABELS[priority]}
    </span>
  );
}
