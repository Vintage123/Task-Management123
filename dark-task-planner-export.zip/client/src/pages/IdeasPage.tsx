import { trpc } from "@/lib/trpc";
import { IDEA_STATUS_LABELS, IdeaRow, IdeaStatus, parseTags } from "@/lib/types";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import {
  ArrowRight,
  Lightbulb,
  Pencil,
  Plus,
  Tag,
  Trash2,
  X,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const STATUS_COLORS: Record<IdeaStatus, string> = {
  brainstorm: "text-[oklch(0.78_0.22_75)] border-[oklch(0.78_0.22_75/0.4)] bg-[oklch(0.78_0.22_75/0.08)]",
  refined: "text-[oklch(0.78_0.22_195)] border-[oklch(0.78_0.22_195/0.4)] bg-[oklch(0.78_0.22_195/0.08)]",
  "in-progress": "text-[oklch(0.65_0.28_330)] border-[oklch(0.65_0.28_330/0.4)] bg-[oklch(0.65_0.28_330/0.08)]",
  implemented: "text-[oklch(0.75_0.22_145)] border-[oklch(0.75_0.22_145/0.4)] bg-[oklch(0.75_0.22_145/0.08)]",
  archived: "text-muted-foreground border-border bg-muted/30",
};

export default function IdeasPage() {
  const utils = trpc.useUtils();
  const [captureTitle, setCaptureTitle] = useState("");
  const [captureContent, setCaptureContent] = useState("");
  const [captureTags, setCaptureTags] = useState<string[]>([]);
  const [captureTagInput, setCaptureTagInput] = useState("");
  const [editingIdea, setEditingIdea] = useState<IdeaRow | null>(null);
  const [promoteIdea, setPromoteIdea] = useState<IdeaRow | null>(null);
  const [filterStatus, setFilterStatus] = useState<IdeaStatus | "all">("all");

  const { data: ideas = [], isLoading } = trpc.ideas.list.useQuery();

  const createMutation = trpc.ideas.create.useMutation({
    onSuccess: () => {
      utils.ideas.list.invalidate();
      setCaptureTitle("");
      setCaptureContent("");
      setCaptureTags([]);
      toast.success("Idea captured");
    },
    onError: () => toast.error("Failed to capture idea"),
  });

  const updateMutation = trpc.ideas.update.useMutation({
    onSuccess: () => {
      utils.ideas.list.invalidate();
      setEditingIdea(null);
      toast.success("Idea updated");
    },
    onError: () => toast.error("Failed to update idea"),
  });

  const deleteMutation = trpc.ideas.delete.useMutation({
    onSuccess: () => {
      utils.ideas.list.invalidate();
      toast.success("Idea deleted");
    },
    onError: () => toast.error("Failed to delete idea"),
  });

  const promoteMutation = trpc.ideas.promoteToTask.useMutation({
    onSuccess: (result) => {
      utils.ideas.list.invalidate();
      utils.tasks.list.invalidate();
      setPromoteIdea(null);
      toast.success(`Idea promoted to task #${result.taskId}`);
    },
    onError: () => toast.error("Failed to promote idea"),
  });

  const handleCapture = () => {
    if (!captureTitle.trim()) return toast.error("Title is required");
    createMutation.mutate({
      title: captureTitle.trim(),
      content: captureContent.trim() || undefined,
      tags: captureTags,
    });
  };

  const addCaptureTag = () => {
    const t = captureTagInput.trim().toLowerCase();
    if (t && !captureTags.includes(t)) setCaptureTags([...captureTags, t]);
    setCaptureTagInput("");
  };

  const filteredIdeas = ideas.filter(
    (i) => filterStatus === "all" || i.status === filterStatus
  );

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      {/* Header */}
      <div className="px-6 py-5 border-b border-border flex-shrink-0">
        <h1 className="font-['Orbitron'] text-lg font-bold neon-pink tracking-widest uppercase">
          Ideas
        </h1>
        <p className="text-xs font-mono text-muted-foreground mt-0.5">
          {ideas.length} captured · {ideas.filter((i) => i.status === "brainstorm").length} brainstorming
        </p>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-6 py-5 space-y-6">
          {/* ── Capture Box ── */}
          <div className="hud-panel p-4 space-y-3">
            <div className="flex items-center gap-2 mb-1">
              <Lightbulb className="w-4 h-4 neon-pink" />
              <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">
                Capture New Idea
              </span>
            </div>

            <Input
              value={captureTitle}
              onChange={(e) => setCaptureTitle(e.target.value)}
              placeholder="What's the idea?"
              className="bg-input border-border font-['Rajdhani'] text-sm"
              onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleCapture()}
            />

            <textarea
              value={captureContent}
              onChange={(e) => setCaptureContent(e.target.value)}
              placeholder="Expand on it... (optional)"
              rows={3}
              className="w-full bg-input border border-border rounded-sm px-3 py-2 text-sm font-['Rajdhani'] text-foreground placeholder:text-muted-foreground resize-none focus:outline-none focus:ring-1 focus:ring-ring"
            />

            {/* Tags */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <Input
                  value={captureTagInput}
                  onChange={(e) => setCaptureTagInput(e.target.value)}
                  placeholder="Add tag..."
                  className="bg-input border-border font-mono text-sm pl-9 h-8"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      addCaptureTag();
                    }
                  }}
                />
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={addCaptureTag}
                className="border-border text-xs font-mono h-8"
              >
                Tag
              </Button>
              <Button
                onClick={handleCapture}
                disabled={createMutation.isPending}
                className="btn-neon-pink bg-[oklch(0.65_0.28_330/0.1)] border border-[oklch(0.65_0.28_330/0.5)] text-[oklch(0.65_0.28_330)] hover:bg-[oklch(0.65_0.28_330/0.2)] text-xs font-['Orbitron'] tracking-widest uppercase h-8"
              >
                <Plus className="w-3.5 h-3.5 mr-1" />
                Capture
              </Button>
            </div>

            {captureTags.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {captureTags.map((t) => (
                  <span
                    key={t}
                    className="flex items-center gap-1 px-2 py-0.5 bg-[oklch(0.65_0.28_330/0.1)] border border-[oklch(0.65_0.28_330/0.3)] text-[oklch(0.65_0.28_330)] text-[10px] font-mono rounded-sm"
                  >
                    {t}
                    <button onClick={() => setCaptureTags(captureTags.filter((x) => x !== t))}>
                      <X className="w-2.5 h-2.5" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* ── Filter ── */}
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">
              Filter:
            </span>
            <Select
              value={filterStatus}
              onValueChange={(v) => setFilterStatus(v as IdeaStatus | "all")}
            >
              <SelectTrigger className="w-40 h-7 bg-input border-border text-xs font-mono">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover border-border">
                <SelectItem value="all" className="text-xs font-mono">All</SelectItem>
                {(Object.keys(IDEA_STATUS_LABELS) as IdeaStatus[]).map((s) => (
                  <SelectItem key={s} value={s} className="text-xs font-mono">
                    {IDEA_STATUS_LABELS[s]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* ── Ideas List ── */}
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Zap className="w-6 h-6 neon-pink animate-pulse" />
            </div>
          ) : filteredIdeas.length === 0 ? (
            <div className="flex flex-col items-center gap-3 py-12">
              <Lightbulb className="w-8 h-8 text-muted-foreground" />
              <p className="text-sm text-muted-foreground font-mono">No ideas yet</p>
            </div>
          ) : (
            <div className="space-y-2 stagger-children">
              {filteredIdeas.map((idea) => (
                <IdeaCard
                  key={idea.id}
                  idea={idea as IdeaRow}
                  onEdit={setEditingIdea}
                  onDelete={(id) => {
                    if (confirm("Delete this idea?")) deleteMutation.mutate({ id });
                  }}
                  onPromote={setPromoteIdea}
                  onStatusChange={(id, status) =>
                    updateMutation.mutate({ id, status })
                  }
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Edit Dialog ── */}
      {editingIdea && (
        <IdeaEditDialog
          idea={editingIdea}
          onClose={() => setEditingIdea(null)}
          onSave={(data) => updateMutation.mutate({ id: editingIdea.id, ...data })}
          isPending={updateMutation.isPending}
        />
      )}

      {/* ── Promote Dialog ── */}
      {promoteIdea && (
        <PromoteDialog
          idea={promoteIdea}
          onClose={() => setPromoteIdea(null)}
          onPromote={(data) => promoteMutation.mutate({ id: promoteIdea.id, ...data })}
          isPending={promoteMutation.isPending}
        />
      )}
    </div>
  );
}

// ─── Idea Card ────────────────────────────────────────────────────────────────
function IdeaCard({
  idea,
  onEdit,
  onDelete,
  onPromote,
  onStatusChange,
}: {
  idea: IdeaRow;
  onEdit: (idea: IdeaRow) => void;
  onDelete: (id: number) => void;
  onPromote: (idea: IdeaRow) => void;
  onStatusChange: (id: number, status: IdeaStatus) => void;
}) {
  const tags = parseTags(idea.tags);
  const isImplemented = idea.status === "implemented";

  return (
    <div
      className={cn(
        "hud-panel p-4 group transition-all duration-150",
        isImplemented && "opacity-60"
      )}
    >
      <div className="flex items-start gap-3">
        <Lightbulb
          className={cn(
            "w-4 h-4 mt-0.5 flex-shrink-0",
            isImplemented ? "text-muted-foreground" : "neon-pink"
          )}
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <h3
                className={cn(
                  "font-['Rajdhani'] font-semibold text-sm leading-snug",
                  isImplemented ? "line-through text-muted-foreground" : "text-foreground"
                )}
              >
                {idea.title}
              </h3>
              {idea.content && (
                <p className="text-xs text-muted-foreground mt-1 font-['Rajdhani'] leading-relaxed line-clamp-2">
                  {idea.content}
                </p>
              )}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-1 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
              {!isImplemented && (
                <button
                  className="p-1 text-muted-foreground hover:text-[oklch(0.75_0.22_145)] transition-colors"
                  title="Promote to task"
                  onClick={() => onPromote(idea)}
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
              <button
                className="p-1 text-muted-foreground hover:text-[oklch(0.78_0.22_195)] transition-colors"
                title="Edit"
                onClick={() => onEdit(idea)}
              >
                <Pencil className="w-3.5 h-3.5" />
              </button>
              <button
                className="p-1 text-muted-foreground hover:text-destructive transition-colors"
                title="Delete"
                onClick={() => onDelete(idea.id)}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Footer */}
          <div className="flex items-center gap-3 mt-2 flex-wrap">
            {/* Status selector */}
            <Select
              value={idea.status}
              onValueChange={(v) => onStatusChange(idea.id, v as IdeaStatus)}
            >
              <SelectTrigger
                className={cn(
                  "h-5 text-[10px] font-mono border rounded-sm px-1.5 py-0 tracking-widest uppercase w-auto gap-1",
                  STATUS_COLORS[idea.status]
                )}
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover border-border">
                {(Object.keys(IDEA_STATUS_LABELS) as IdeaStatus[]).map((s) => (
                  <SelectItem key={s} value={s} className="text-[10px] font-mono">
                    {IDEA_STATUS_LABELS[s]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {tags.length > 0 && (
              <div className="flex items-center gap-1 flex-wrap">
                {tags.map((t) => (
                  <span
                    key={t}
                    className="px-1.5 py-0.5 bg-[oklch(0.65_0.28_330/0.08)] border border-[oklch(0.65_0.28_330/0.25)] text-[oklch(0.65_0.28_330)] text-[9px] font-mono rounded-sm"
                  >
                    {t}
                  </span>
                ))}
              </div>
            )}

            <span className="text-[9px] font-mono text-muted-foreground ml-auto">
              {format(new Date(idea.createdAt), "MMM d")}
            </span>

            {idea.convertedTaskId && (
              <span className="text-[9px] font-mono text-[oklch(0.75_0.22_145)]">
                → Task #{idea.convertedTaskId}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Idea Edit Dialog ─────────────────────────────────────────────────────────
function IdeaEditDialog({
  idea,
  onClose,
  onSave,
  isPending,
}: {
  idea: IdeaRow;
  onClose: () => void;
  onSave: (data: { title?: string; content?: string; status?: IdeaStatus; tags?: string[] }) => void;
  isPending: boolean;
}) {
  const [title, setTitle] = useState(idea.title);
  const [content, setContent] = useState(idea.content ?? "");
  const [status, setStatus] = useState<IdeaStatus>(idea.status);
  const [tags, setTags] = useState<string[]>(parseTags(idea.tags));
  const [tagInput, setTagInput] = useState("");

  const addTag = () => {
    const t = tagInput.trim().toLowerCase();
    if (t && !tags.includes(t)) setTags([...tags, t]);
    setTagInput("");
  };

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="bg-card border-border max-w-lg hud-panel">
        <DialogHeader>
          <DialogTitle className="font-['Orbitron'] text-sm font-bold neon-pink tracking-widest uppercase">
            Edit Idea
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 mt-2">
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Idea title..."
            className="bg-input border-border font-['Rajdhani'] text-sm"
          />
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Details..."
            rows={4}
            className="w-full bg-input border border-border rounded-sm px-3 py-2 text-sm font-['Rajdhani'] text-foreground placeholder:text-muted-foreground resize-none focus:outline-none focus:ring-1 focus:ring-ring"
          />
          <Select value={status} onValueChange={(v) => setStatus(v as IdeaStatus)}>
            <SelectTrigger className="bg-input border-border text-xs font-mono h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-popover border-border">
              {(Object.keys(IDEA_STATUS_LABELS) as IdeaStatus[]).map((s) => (
                <SelectItem key={s} value={s} className="text-xs font-mono">
                  {IDEA_STATUS_LABELS[s]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex gap-2">
            <Input
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              placeholder="Add tag..."
              className="bg-input border-border font-mono text-sm h-8"
              onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addTag(); } }}
            />
            <Button variant="outline" size="sm" onClick={addTag} className="border-border text-xs font-mono h-8">Tag</Button>
          </div>
          {tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {tags.map((t) => (
                <span key={t} className="flex items-center gap-1 px-2 py-0.5 bg-[oklch(0.65_0.28_330/0.1)] border border-[oklch(0.65_0.28_330/0.3)] text-[oklch(0.65_0.28_330)] text-[10px] font-mono rounded-sm">
                  {t}<button onClick={() => setTags(tags.filter((x) => x !== t))}><X className="w-2.5 h-2.5" /></button>
                </span>
              ))}
            </div>
          )}
          <div className="flex gap-3 pt-2">
            <Button variant="outline" className="flex-1 border-border text-xs font-mono tracking-widest uppercase" onClick={onClose}>Cancel</Button>
            <Button
              className="flex-1 btn-neon-pink bg-[oklch(0.65_0.28_330/0.1)] border border-[oklch(0.65_0.28_330/0.5)] text-[oklch(0.65_0.28_330)] hover:bg-[oklch(0.65_0.28_330/0.2)] text-xs font-['Orbitron'] tracking-widest uppercase"
              onClick={() => onSave({ title, content: content || undefined, status, tags })}
              disabled={isPending}
            >
              {isPending ? "Saving..." : "Update"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ─── Promote Dialog ───────────────────────────────────────────────────────────
function PromoteDialog({
  idea,
  onClose,
  onPromote,
  isPending,
}: {
  idea: IdeaRow;
  onClose: () => void;
  onPromote: (data: { title?: string; description?: string; priority?: "low" | "medium" | "high" | "urgent" }) => void;
  isPending: boolean;
}) {
  const [title, setTitle] = useState(idea.title);
  const [description, setDescription] = useState(idea.content ?? "");
  const [priority, setPriority] = useState<"low" | "medium" | "high" | "urgent">("medium");

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="bg-card border-border max-w-lg hud-panel">
        <DialogHeader>
          <DialogTitle className="font-['Orbitron'] text-sm font-bold neon-cyan tracking-widest uppercase flex items-center gap-2">
            <ArrowRight className="w-4 h-4" />
            Promote to Task
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 mt-2">
          <p className="text-xs font-mono text-muted-foreground">
            This idea will be converted to a task and marked as implemented.
          </p>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Task title..."
            className="bg-input border-border font-['Rajdhani'] text-sm"
          />
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Task description..."
            rows={3}
            className="w-full bg-input border border-border rounded-sm px-3 py-2 text-sm font-['Rajdhani'] text-foreground placeholder:text-muted-foreground resize-none focus:outline-none focus:ring-1 focus:ring-ring"
          />
          <Select value={priority} onValueChange={(v) => setPriority(v as typeof priority)}>
            <SelectTrigger className="bg-input border-border text-xs font-mono h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-popover border-border">
              <SelectItem value="low" className="text-xs font-mono">Low Priority</SelectItem>
              <SelectItem value="medium" className="text-xs font-mono">Medium Priority</SelectItem>
              <SelectItem value="high" className="text-xs font-mono">High Priority</SelectItem>
              <SelectItem value="urgent" className="text-xs font-mono">Urgent Priority</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex gap-3 pt-2">
            <Button variant="outline" className="flex-1 border-border text-xs font-mono tracking-widest uppercase" onClick={onClose}>Cancel</Button>
            <Button
              className="flex-1 btn-neon-cyan bg-[oklch(0.78_0.22_195/0.1)] border border-[oklch(0.78_0.22_195/0.5)] text-[oklch(0.78_0.22_195)] hover:bg-[oklch(0.78_0.22_195/0.2)] text-xs font-['Orbitron'] tracking-widest uppercase"
              onClick={() => onPromote({ title, description: description || undefined, priority })}
              disabled={isPending}
            >
              {isPending ? "Promoting..." : "Promote to Task"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
