import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { cn } from "@/lib/utils";
import {
  Lightbulb,
  ListTodo,
  LogOut,
  User,
  Zap,
} from "lucide-react";
import { ReactNode } from "react";
import { Link, useLocation } from "wouter";

const NAV_ITEMS = [
  { href: "/tasks", label: "Tasks", icon: ListTodo },
  { href: "/ideas", label: "Ideas", icon: Lightbulb },
];

export default function AppShell({ children }: { children: ReactNode }) {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [location] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Zap className="w-10 h-10 neon-cyan animate-pulse" />
          <p className="font-mono text-sm text-muted-foreground tracking-widest uppercase">
            Initializing System...
          </p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center scanlines">
        <div className="hud-panel p-10 flex flex-col items-center gap-8 max-w-sm w-full mx-4">
          {/* Logo */}
          <div className="flex flex-col items-center gap-3">
            <Zap className="w-12 h-12 neon-cyan" />
            <h1
              className="font-['Orbitron'] text-2xl font-bold neon-cyan tracking-widest uppercase"
            >
              Dark Task
            </h1>
            <p className="text-muted-foreground text-xs font-mono tracking-widest uppercase text-center">
              Personal Productivity HUD
            </p>
          </div>

          {/* Neon divider */}
          <div className="neon-divider w-full" />

          {/* Login */}
          <a
            href={getLoginUrl()}
            className="w-full flex items-center justify-center gap-2 px-6 py-3 border border-[oklch(0.78_0.22_195/0.6)] bg-[oklch(0.78_0.22_195/0.08)] text-[oklch(0.78_0.22_195)] font-['Orbitron'] text-sm font-semibold tracking-widest uppercase btn-neon-cyan transition-all duration-150"
          >
            <Zap className="w-4 h-4" />
            Access Terminal
          </a>

          <p className="text-muted-foreground text-xs font-mono text-center">
            Authenticate to enter the system
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* ── Sidebar ── */}
      <aside className="w-14 md:w-56 flex-shrink-0 flex flex-col border-r border-border bg-sidebar">
        {/* Brand */}
        <div className="px-4 py-5 border-b border-border">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 neon-cyan flex-shrink-0" />
            <span className="hidden md:inline font-['Orbitron'] text-sm font-bold neon-cyan tracking-widest uppercase">
              Dark Task
            </span>
          </div>
          <p className="hidden md:block text-[10px] font-mono text-muted-foreground mt-1 tracking-widest uppercase">
            HUD v1.0
          </p>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-2 py-4 space-y-1">
          {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
            const active = location === href || (href === "/tasks" && location === "/");
            return (
              <Link key={href} href={href}>
                <div
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 text-sm font-semibold tracking-wide transition-all duration-150 cursor-pointer relative group",
                    active
                      ? "text-[oklch(0.78_0.22_195)] bg-[oklch(0.78_0.22_195/0.08)] border border-[oklch(0.78_0.22_195/0.3)]"
                      : "text-sidebar-foreground hover:text-[oklch(0.78_0.22_195)] hover:bg-[oklch(0.78_0.22_195/0.05)] border border-transparent"
                  )}
                >
                  {active && (
                    <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-4 bg-[oklch(0.78_0.22_195)] shadow-[0_0_6px_oklch(0.78_0.22_195)]" />
                  )}
                  <Icon className={cn("w-4 h-4", active && "neon-cyan")} />
                  <span className="hidden md:inline font-['Rajdhani'] uppercase tracking-widest">{label}</span>
                </div>
              </Link>
            );
          })}
        </nav>

        {/* User section */}
        <div className="px-3 py-4 border-t border-border">
            <div className="flex items-center gap-2 px-2 py-2">
              <div className="w-7 h-7 rounded-sm bg-[oklch(0.78_0.22_195/0.15)] border border-[oklch(0.78_0.22_195/0.3)] flex items-center justify-center flex-shrink-0">
                <User className="w-3.5 h-3.5 text-[oklch(0.78_0.22_195)]" />
              </div>
              <div className="hidden md:block flex-1 min-w-0">
                <p className="text-xs font-semibold text-sidebar-foreground truncate font-['Rajdhani'] tracking-wide">
                  {user?.name ?? "Operator"}
                </p>
                <p className="text-[10px] text-muted-foreground font-mono truncate">
                  {user?.email ?? ""}
                </p>
              </div>
            </div>
          <button
            onClick={() => logout()}
            className="mt-2 w-full flex items-center gap-2 px-3 py-2 text-xs text-muted-foreground hover:text-destructive transition-colors duration-150 font-mono tracking-widest uppercase"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Logout</span>
          </button>
        </div>
      </aside>

      {/* ── Main content ── */}
      <main className="flex-1 overflow-auto min-w-0">
        {children}
      </main>
    </div>
  );
}
