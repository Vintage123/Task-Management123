import { trpc } from "@/lib/trpc";
import { TaskPriority, TaskRow, TaskStatus } from "@/lib/types";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { Calendar, Tag, X } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface TaskDialogProps {
  open: boolean;
  task?: TaskRow | null;
  defaultParentId?: number;
  onClose: () => void;
}

export default function TaskDialog({ open, task, defaultParentId, onClose }: TaskDialogProps) {
  const utils = trpc.useUtils();
  const isEdit = !!task;

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState<TaskStatus>("todo");
  const [priority, setPriority] = useState<TaskPriority>("medium");
  const [dueDate, setDueDate] = useState("");
  const [tagInput, setTagInput] = useState("");
  const [tags, setTags] = useState<string[]>([]);

  useEffect(() => {
    if (task) {
      setTitle(task.title);
      setDescription(task.description ?? "");
      setStatus(task.status);
      setPriority(task.priority);
      setDueDate(task.dueDate ? format(new Date(task.dueDate), "yyyy-MM-dd") : "");
      try {
        setTags(task.tags ? JSON.parse(task.tags) : []);
      } catch {
        setTags([]);
      }
    } else {
      setTitle("");
      setDescription("");
      setStatus("todo");
      setPriority("medium");
      setDueDate("");
      setTags([]);
    }
  }, [task, open]);

  const createMutation = trpc.tasks.create.useMutation({
    onSuccess: () => {
      utils.tasks.list.invalidate();
      toast.success("Task created");
      onClose();
    },
    onError: () => toast.error("Failed to create task"),
  });

  const updateMutation = trpc.tasks.update.useMutation({
    onSuccess: () => {
      utils.tasks.list.invalidate();
      toast.success("Task updated");
      onClose();
    },
    onError: () => toast.error("Failed to update task"),
  });

  const handleSubmit = () => {
    if (!title.trim()) return toast.error("Title is required");

    const payload = {
      title: title.trim(),
      description: description.trim() || undefined,
      status,
      priority,
      dueDate: dueDate ? new Date(dueDate) : null,
      tags,
    };

    if (isEdit) {
      updateMutation.mutate({ id: task!.id, ...payload });
    } else {
      createMutation.mutate({
        ...payload,
        parentId: defaultParentId ?? null,
      });
    }
  };

  const addTag = () => {
    const t = tagInput.trim().toLowerCase();
    if (t && !tags.includes(t)) {
      setTags([...tags, t]);
    }
    setTagInput("");
  };

  const removeTag = (t: string) => setTags(tags.filter((x) => x !== t));

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="bg-card border-border max-w-lg hud-panel">
        <DialogHeader>
          <DialogTitle className="font-['Orbitron'] text-sm font-bold neon-cyan tracking-widest uppercase">
            {isEdit ? "Edit Task" : defaultParentId ? "Add Subtask" : "New Task"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          {/* Title */}
          <div>
            <label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mb-1.5 block">
              Title *
            </label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Task title..."
              className="bg-input border-border font-['Rajdhani'] text-sm"
              onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
            />
          </div>

          {/* Description */}
          <div>
            <label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mb-1.5 block">
              Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Optional description..."
              rows={3}
              className="w-full bg-input border border-border rounded-sm px-3 py-2 text-sm font-['Rajdhani'] text-foreground placeholder:text-muted-foreground resize-none focus:outline-none focus:ring-1 focus:ring-ring"
            />
          </div>

          {/* Status + Priority */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mb-1.5 block">
                Status
              </label>
              <Select value={status} onValueChange={(v) => setStatus(v as TaskStatus)}>
                <SelectTrigger className="bg-input border-border text-xs font-mono h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  <SelectItem value="todo" className="text-xs font-mono">Todo</SelectItem>
                  <SelectItem value="in-progress" className="text-xs font-mono">In Progress</SelectItem>
                  <SelectItem value="done" className="text-xs font-mono">Done</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mb-1.5 block">
                Priority
              </label>
              <Select value={priority} onValueChange={(v) => setPriority(v as TaskPriority)}>
                <SelectTrigger className="bg-input border-border text-xs font-mono h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  <SelectItem value="low" className="text-xs font-mono">Low</SelectItem>
                  <SelectItem value="medium" className="text-xs font-mono">Medium</SelectItem>
                  <SelectItem value="high" className="text-xs font-mono">High</SelectItem>
                  <SelectItem value="urgent" className="text-xs font-mono">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Due Date */}
          <div>
            <label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mb-1.5 block">
              Due Date
            </label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="bg-input border-border font-mono text-sm pl-9"
              />
            </div>
          </div>

          {/* Tags */}
          <div>
            <label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mb-1.5 block">
              Tags
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <Input
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  placeholder="Add tag..."
                  className="bg-input border-border font-mono text-sm pl-9"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      addTag();
                    }
                  }}
                />
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={addTag}
                className="border-border text-xs font-mono"
              >
                Add
              </Button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {tags.map((t) => (
                  <span
                    key={t}
                    className="flex items-center gap-1 px-2 py-0.5 bg-[oklch(0.78_0.22_195/0.1)] border border-[oklch(0.78_0.22_195/0.3)] text-[oklch(0.78_0.22_195)] text-[10px] font-mono rounded-sm"
                  >
                    {t}
                    <button onClick={() => removeTag(t)}>
                      <X className="w-2.5 h-2.5" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-2">
            <Button
              variant="outline"
              className="flex-1 border-border text-xs font-mono tracking-widest uppercase"
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button
              className="flex-1 btn-neon-cyan bg-[oklch(0.78_0.22_195/0.1)] border border-[oklch(0.78_0.22_195/0.5)] text-[oklch(0.78_0.22_195)] hover:bg-[oklch(0.78_0.22_195/0.2)] text-xs font-['Orbitron'] tracking-widest uppercase"
              onClick={handleSubmit}
              disabled={isPending}
            >
              {isPending ? "Saving..." : isEdit ? "Update" : "Create"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
