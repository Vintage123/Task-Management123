import { trpc } from "@/lib/trpc";
import { parseTags, TaskRow } from "@/lib/types";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { Calendar, Pencil, Paperclip, PenTool, X } from "lucide-react";
import { useState } from "react";
import { PriorityBadge } from "@/pages/TasksPage";
import FileAttachments from "@/components/FileAttachments";
import DrawingPanel from "@/components/DrawingPanel";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface TaskDetailPanelProps {
  taskId: number;
  onClose: () => void;
  onEdit: (task: TaskRow) => void;
}

export default function TaskDetailPanel({ taskId, onClose, onEdit }: TaskDetailPanelProps) {
  const { data: task, isLoading } = trpc.tasks.getById.useQuery({ id: taskId });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-4 h-4 border-2 border-[oklch(0.78_0.22_195)] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!task) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground text-sm font-mono">
        Task not found
      </div>
    );
  }

  const tags = parseTags(task.tags);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 py-4 border-b border-border flex items-start justify-between gap-3 flex-shrink-0">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span
              className={cn(
                "px-1.5 py-0.5 text-[10px] font-mono border rounded-sm tracking-widest uppercase",
                task.status === "todo" && "status-todo",
                task.status === "in-progress" && "status-in-progress",
                task.status === "done" && "status-done"
              )}
            >
              {task.status === "todo" ? "TODO" : task.status === "in-progress" ? "WIP" : "DONE"}
            </span>
            <PriorityBadge priority={task.priority} />
          </div>
          <h2 className="mt-2 font-['Orbitron'] text-sm font-bold text-foreground tracking-wide leading-snug">
            {task.title}
          </h2>
        </div>
        <div className="flex items-center gap-1 flex-shrink-0">
          <button
            onClick={() => onEdit(task as TaskRow)}
            className="p-1.5 text-muted-foreground hover:text-[oklch(0.78_0.22_195)] transition-colors"
          >
            <Pencil className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onClose}
            className="p-1.5 text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Meta */}
      <div className="px-5 py-3 border-b border-border flex-shrink-0 space-y-2">
        {task.dueDate && (
          <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
            <Calendar className="w-3 h-3" />
            <span>Due {format(new Date(task.dueDate), "MMM d, yyyy")}</span>
          </div>
        )}
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {tags.map((t) => (
              <span
                key={t}
                className="px-2 py-0.5 bg-[oklch(0.78_0.22_195/0.1)] border border-[oklch(0.78_0.22_195/0.3)] text-[oklch(0.78_0.22_195)] text-[10px] font-mono rounded-sm"
              >
                {t}
              </span>
            ))}
          </div>
        )}
        {task.description && (
          <p className="text-sm text-muted-foreground font-['Rajdhani'] leading-relaxed">
            {task.description}
          </p>
        )}
      </div>

      {/* Tabs: Files & Canvas */}
      <div className="flex-1 overflow-hidden">
        <Tabs defaultValue="files" className="h-full flex flex-col">
          <TabsList className="mx-5 mt-3 mb-0 bg-muted/50 border border-border h-8 flex-shrink-0">
            <TabsTrigger
              value="files"
              className="flex-1 text-[10px] font-mono tracking-widest uppercase data-[state=active]:text-[oklch(0.78_0.22_195)] data-[state=active]:bg-[oklch(0.78_0.22_195/0.1)]"
            >
              <Paperclip className="w-3 h-3 mr-1.5" />
              Files
            </TabsTrigger>
            <TabsTrigger
              value="canvas"
              className="flex-1 text-[10px] font-mono tracking-widest uppercase data-[state=active]:text-[oklch(0.78_0.22_195)] data-[state=active]:bg-[oklch(0.78_0.22_195/0.1)]"
            >
              <PenTool className="w-3 h-3 mr-1.5" />
              Canvas
            </TabsTrigger>
          </TabsList>
          <TabsContent value="files" className="flex-1 overflow-y-auto mt-0 px-5 py-3">
            <FileAttachments taskId={taskId} />
          </TabsContent>
          <TabsContent value="canvas" className="flex-1 overflow-hidden mt-0">
            <DrawingPanel taskId={taskId} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
