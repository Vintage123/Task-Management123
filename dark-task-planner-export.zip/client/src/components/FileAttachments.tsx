import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { useDropzone } from "react-dropzone";
import {
  Download,
  File,
  FileImage,
  FileText,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function getFileIcon(mimeType: string) {
  if (mimeType.startsWith("image/")) return FileImage;
  if (mimeType === "application/pdf" || mimeType.includes("text")) return FileText;
  return File;
}

interface FileAttachmentsProps {
  taskId: number;
}

export default function FileAttachments({ taskId }: FileAttachmentsProps) {
  const utils = trpc.useUtils();
  const [uploading, setUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewMime, setPreviewMime] = useState<string | null>(null);

  const { data: files = [], isLoading } = trpc.files.getByTask.useQuery({ taskId });

  const uploadMutation = trpc.files.upload.useMutation({
    onSuccess: () => {
      utils.files.getByTask.invalidate({ taskId });
      toast.success("File uploaded");
    },
    onError: (e) => toast.error(e.message || "Upload failed"),
  });

  const deleteMutation = trpc.files.delete.useMutation({
    onSuccess: () => {
      utils.files.getByTask.invalidate({ taskId });
      toast.success("File removed");
    },
    onError: () => toast.error("Failed to delete file"),
  });

  const onDrop = async (accepted: File[]) => {
    for (const file of accepted) {
      if (file.size > MAX_FILE_SIZE) {
        toast.error(`${file.name} exceeds 100MB limit`);
        continue;
      }
      setUploading(true);
      try {
        const base64 = await fileToBase64(file);
        await uploadMutation.mutateAsync({
          taskId,
          name: file.name,
          mimeType: file.type || "application/octet-stream",
          size: file.size,
          base64Data: base64,
        });
      } finally {
        setUploading(false);
      }
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    maxSize: MAX_FILE_SIZE,
    multiple: true,
  });

  return (
    <div className="space-y-3">
      {/* Drop zone */}
      <div
        {...getRootProps()}
        className={cn(
          "border border-dashed rounded-sm px-4 py-5 flex flex-col items-center gap-2 cursor-pointer transition-all duration-150",
          isDragActive
            ? "border-[oklch(0.78_0.22_195/0.8)] bg-[oklch(0.78_0.22_195/0.06)]"
            : "border-border hover:border-[oklch(0.78_0.22_195/0.4)] hover:bg-[oklch(0.78_0.22_195/0.03)]"
        )}
      >
        <input {...getInputProps()} />
        <Upload
          className={cn(
            "w-5 h-5 transition-colors",
            isDragActive ? "text-[oklch(0.78_0.22_195)]" : "text-muted-foreground"
          )}
        />
        <p className="text-[10px] font-mono text-muted-foreground text-center">
          {isDragActive
            ? "Drop files here..."
            : uploading
            ? "Uploading..."
            : "Drag & drop or click to attach files"}
        </p>
        <p className="text-[9px] font-mono text-muted-foreground/60">
          PDF, images, documents — max 100MB each
        </p>
      </div>

      {/* File list */}
      {isLoading ? (
        <div className="text-center py-4">
          <div className="w-4 h-4 border-2 border-[oklch(0.78_0.22_195)] border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      ) : files.length === 0 ? (
        <p className="text-center text-[10px] font-mono text-muted-foreground py-2">
          No attachments yet
        </p>
      ) : (
        <div className="space-y-1.5">
          {files.map((f) => {
            const Icon = getFileIcon(f.mimeType);
            const isImage = f.mimeType.startsWith("image/");
            return (
              <div
                key={f.id}
                className="flex items-center gap-2.5 px-3 py-2 bg-muted/30 border border-border rounded-sm group hover:border-[oklch(0.78_0.22_195/0.3)] transition-all duration-150"
              >
                <Icon className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-['Rajdhani'] font-semibold text-foreground truncate">
                    {f.name}
                  </p>
                  <p className="text-[10px] font-mono text-muted-foreground">
                    {formatBytes(f.size)} · {f.mimeType.split("/")[1]?.toUpperCase()} · {new Date(f.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  {isImage && (
                    <button
                      className="p-1 text-muted-foreground hover:text-[oklch(0.78_0.22_195)] transition-colors"
                      title="Preview"
                      onClick={() => {
                        setPreviewUrl(f.storageUrl);
                        setPreviewMime(f.mimeType);
                      }}
                    >
                      <FileImage className="w-3.5 h-3.5" />
                    </button>
                  )}
                  <a
                    href={f.storageUrl}
                    download={f.name}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1 text-muted-foreground hover:text-[oklch(0.78_0.22_195)] transition-colors"
                    title="Download"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <Download className="w-3.5 h-3.5" />
                  </a>
                  <button
                    className="p-1 text-muted-foreground hover:text-destructive transition-colors"
                    title="Delete"
                    onClick={() => {
                      if (confirm("Remove this attachment?")) {
                        deleteMutation.mutate({ id: f.id });
                      }
                    }}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Image preview modal */}
      {previewUrl && previewMime?.startsWith("image/") && (
        <div
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          onClick={() => setPreviewUrl(null)}
        >
          <div className="relative max-w-3xl max-h-[80vh]">
            <button
              className="absolute -top-8 right-0 text-white/70 hover:text-white"
              onClick={() => setPreviewUrl(null)}
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={previewUrl}
              alt="Preview"
              className="max-w-full max-h-[80vh] object-contain rounded-sm border border-border"
            />
          </div>
        </div>
      )}
    </div>
  );
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(",")[1] ?? "");
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
