import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { Pencil, Plus, Save, Trash2, X } from "lucide-react";
import { lazy, Suspense, useCallback, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type ExcalidrawImperativeAPI = any;

// Lazy-load Excalidraw to avoid SSR issues and reduce initial bundle
const Excalidraw = lazy(() =>
  import("@excalidraw/excalidraw").then((m) => ({ default: m.Excalidraw }))
);

interface DrawingPanelProps {
  taskId: number;
}

export default function DrawingPanel({ taskId }: DrawingPanelProps) {
  const utils = trpc.useUtils();
  const [activeDrawingId, setActiveDrawingId] = useState<number | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [drawingData, setDrawingData] = useState<string | null>(null);
  const [drawingName, setDrawingName] = useState("Untitled Canvas");
  const excalidrawAPIRef = useRef<ExcalidrawImperativeAPI | null>(null);

  const { data: drawings = [], isLoading } = trpc.drawings.getByTask.useQuery({ taskId });

  const upsertMutation = trpc.drawings.upsert.useMutation({
    onSuccess: (result) => {
      utils.drawings.getByTask.invalidate({ taskId });
      setActiveDrawingId(result.id);
      toast.success("Canvas saved");
    },
    onError: () => toast.error("Failed to save canvas"),
  });

  const deleteMutation = trpc.drawings.delete.useMutation({
    onSuccess: () => {
      utils.drawings.getByTask.invalidate({ taskId });
      setActiveDrawingId(null);
      setIsEditing(false);
      setDrawingData(null);
      toast.success("Canvas deleted");
    },
    onError: () => toast.error("Failed to delete canvas"),
  });

  const openDrawing = (drawing: { id: number; name: string; data: string }) => {
    setActiveDrawingId(drawing.id);
    setDrawingName(drawing.name);
    setDrawingData(drawing.data);
    setIsEditing(true);
  };

  const createNew = () => {
    setActiveDrawingId(null);
    setDrawingName("Untitled Canvas");
    setDrawingData(null);
    setIsEditing(true);
  };

  const handleSave = useCallback(() => {
    if (!excalidrawAPIRef.current) return;
    const api = excalidrawAPIRef.current;
    const elements = api.getSceneElements();
    const appState = api.getAppState();
    const data = JSON.stringify({ elements, appState: { ...appState, collaborators: [] } });

    upsertMutation.mutate({
      id: activeDrawingId ?? undefined,
      taskId,
      name: drawingName,
      data,
    });
  }, [activeDrawingId, taskId, drawingName, upsertMutation]);

  const initialData = drawingData
    ? (() => {
        try {
          return JSON.parse(drawingData);
        } catch {
          return undefined;
        }
      })()
    : undefined;

  if (isEditing) {
    return (
      <div className="flex flex-col h-full">
        {/* Canvas toolbar */}
        <div className="flex items-center gap-2 px-3 py-2 border-b border-border flex-shrink-0">
          <input
            value={drawingName}
            onChange={(e) => setDrawingName(e.target.value)}
            className="flex-1 bg-transparent text-xs font-mono text-foreground border-b border-transparent focus:border-[oklch(0.78_0.22_195/0.5)] focus:outline-none px-1 py-0.5"
            placeholder="Canvas name..."
          />
          <Button
            size="sm"
            onClick={handleSave}
            disabled={upsertMutation.isPending}
            className="h-7 text-[10px] btn-neon-cyan bg-[oklch(0.78_0.22_195/0.1)] border border-[oklch(0.78_0.22_195/0.5)] text-[oklch(0.78_0.22_195)] hover:bg-[oklch(0.78_0.22_195/0.2)] font-mono tracking-widest uppercase"
          >
            <Save className="w-3 h-3 mr-1" />
            {upsertMutation.isPending ? "Saving..." : "Save"}
          </Button>
          <button
            onClick={() => setIsEditing(false)}
            className="p-1 text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Excalidraw canvas */}
        <div className="flex-1 overflow-hidden">
          <Suspense
            fallback={
              <div className="flex items-center justify-center h-full">
                <div className="w-4 h-4 border-2 border-[oklch(0.78_0.22_195)] border-t-transparent rounded-full animate-spin" />
              </div>
            }
          >
            <Excalidraw
              excalidrawAPI={(api) => { excalidrawAPIRef.current = api; }}
              initialData={initialData}
              theme="dark"
              UIOptions={{
                canvasActions: {
                  export: false,
                  loadScene: false,
                  saveToActiveFile: false,
                  toggleTheme: false,
                },
              }}
            />
          </Suspense>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-3">
      {/* Create button */}
      <Button
        onClick={createNew}
        className="w-full btn-neon-cyan bg-[oklch(0.78_0.22_195/0.08)] border border-[oklch(0.78_0.22_195/0.4)] text-[oklch(0.78_0.22_195)] hover:bg-[oklch(0.78_0.22_195/0.15)] text-xs font-['Orbitron'] tracking-widest uppercase"
      >
        <Plus className="w-3.5 h-3.5 mr-1.5" />
        New Canvas
      </Button>

      {/* Drawing list */}
      {isLoading ? (
        <div className="flex justify-center py-4">
          <div className="w-4 h-4 border-2 border-[oklch(0.78_0.22_195)] border-t-transparent rounded-full animate-spin" />
        </div>
      ) : drawings.length === 0 ? (
        <p className="text-center text-[10px] font-mono text-muted-foreground py-2">
          No canvases yet
        </p>
      ) : (
        <div className="space-y-1.5">
          {drawings.map((d) => (
            <div
              key={d.id}
              className="flex items-center gap-2.5 px-3 py-2.5 bg-muted/30 border border-border rounded-sm group hover:border-[oklch(0.78_0.22_195/0.3)] transition-all duration-150 cursor-pointer"
              onClick={() => openDrawing(d)}
            >
              <Pencil className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-['Rajdhani'] font-semibold text-foreground truncate">
                  {d.name}
                </p>
                <p className="text-[10px] font-mono text-muted-foreground">
                  Updated {new Date(d.updatedAt).toLocaleDateString()}
                </p>
              </div>
              <button
                className="p-1 text-muted-foreground hover:text-destructive transition-colors opacity-0 group-hover:opacity-100"
                title="Delete canvas"
                onClick={(e) => {
                  e.stopPropagation();
                  if (confirm("Delete this canvas?")) {
                    deleteMutation.mutate({ id: d.id });
                  }
                }}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
