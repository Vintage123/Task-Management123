import { trpc } from "@/lib/trpc";
import { TaskPriority } from "@/lib/types";
import { cn } from "@/lib/utils";
import { useDropzone } from "react-dropzone";
import {
  AlertCircle,
  CheckCircle2,
  FileText,
  Loader2,
  Upload,
  X,
  Zap,
} from "lucide-react";
import { useState, useCallback } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// ─── Parser ───────────────────────────────────────────────────────────────────
/**
 * Parses a text file into individual task titles.
 * Handles formats:
 *   1. Task title
 *   1) Task title
 *   1 - Task title
 *   - Task title
 *   • Task title
 *   * Task title
 *   Plain line (no prefix)
 */
function parseTextToTasks(raw: string): string[] {
  const lines = raw.split(/\r?\n/);
  const results: string[] = [];

  for (const line of lines) {
    // Strip leading/trailing whitespace
    const trimmed = line.trim();
    if (!trimmed) continue;

    // Remove common list prefixes:
    // numbered:  "123." / "123)" / "123 -" / "123 ."
    // bullet:    "-" / "•" / "*" / "·" / "–" / "—"
    const stripped = trimmed
      .replace(/^\d+[\.\)\-\s]+\s*/, "")   // numbered list
      .replace(/^[-•*·–—]\s+/, "")          // bullet list
      .trim();

    if (stripped.length > 0 && stripped.length <= 512) {
      results.push(stripped);
    }
    // Safety cap to avoid browser memory issues
    if (results.length >= 2000) break;
  }

  return results;
}

// ─── Component ────────────────────────────────────────────────────────────────
interface ImportDialogProps {
  open: boolean;
  onClose: () => void;
}

type ParentOption = { id: number; title: string };

type Step = "upload" | "preview" | "done";

export default function ImportDialog({ open, onClose }: ImportDialogProps) {
  const utils = trpc.useUtils();

  const [step, setStep] = useState<Step>("upload");
  const [fileName, setFileName] = useState("");
  const [parsedTitles, setParsedTitles] = useState<string[]>([]);
  const [editedTitles, setEditedTitles] = useState<string[]>([]);
  const [removedIndices, setRemovedIndices] = useState<Set<number>>(new Set());
  const [priority, setPriority] = useState<TaskPriority>("medium");
  const [tagInput, setTagInput] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [parentId, setParentId] = useState<string>("none");
  const [importedCount, setImportedCount] = useState(0);

  // Load top-level tasks as parent options
  const { data: allTasks = [] } = trpc.tasks.list.useQuery(undefined, { enabled: open });

  const bulkCreateMutation = trpc.tasks.bulkCreate.useMutation({
    onSuccess: (result) => {
      utils.tasks.list.invalidate();
      setImportedCount(result.count);
      setStep("done");
      toast.success(`${result.count} tasks imported successfully`);
    },
    onError: (e) => toast.error(e.message || "Import failed"),
  });

  const handleReset = useCallback(() => {
    setStep("upload");
    setFileName("");
    setParsedTitles([]);
    setEditedTitles([]);
    setRemovedIndices(new Set());
    setPriority("medium");
    setTagInput("");
    setTags([]);
    setParentId("none");
    setImportedCount(0);
  }, []);

  const handleClose = () => {
    handleReset();
    onClose();
  };

  const onDrop = useCallback((accepted: File[]) => {
    const file = accepted[0];
    if (!file) return;
    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const titles = parseTextToTasks(text);
      if (titles.length === 0) {
        toast.error("No valid task lines found in this file");
        return;
      }
      setParsedTitles(titles);
      setEditedTitles([...titles]);
      setRemovedIndices(new Set());
      setStep("preview");
    };
    reader.readAsText(file);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { "text/plain": [".txt"], "text/markdown": [".md"], "text/csv": [".csv"] },
    maxFiles: 1,
    multiple: false,
  });

  const toggleRemove = (i: number) => {
    setRemovedIndices((prev) => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });
  };

  const handleImport = () => {
    const titles = editedTitles.filter((_, i) => !removedIndices.has(i)).filter(Boolean);
    if (titles.length === 0) {
      toast.error("No tasks to import");
      return;
    }
    bulkCreateMutation.mutate({
      titles,
      priority,
      tags,
      parentId: parentId !== "none" ? Number(parentId) : null,
    });
  };

  const activeCount = editedTitles.filter((_, i) => !removedIndices.has(i)).length;

  return (
    <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
      <DialogContent className="bg-card border-border max-w-2xl hud-panel max-h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="font-['Orbitron'] text-sm font-bold neon-pink tracking-widest uppercase flex items-center gap-2">
            <Upload className="w-4 h-4" />
            Bulk Import Tasks
          </DialogTitle>
        </DialogHeader>

        {/* ── Step: Upload ── */}
        {step === "upload" && (
          <div className="space-y-4 mt-2">
            <p className="text-xs font-mono text-muted-foreground leading-relaxed">
              Drop a <span className="text-foreground">.txt</span>,{" "}
              <span className="text-foreground">.md</span>, or{" "}
              <span className="text-foreground">.csv</span> file containing a numbered or
              bulleted list. Each non-empty line becomes an individual task.
            </p>

            <div
              {...getRootProps()}
              className={cn(
                "border-2 border-dashed rounded-sm px-6 py-12 flex flex-col items-center gap-4 cursor-pointer transition-all duration-200",
                isDragActive
                  ? "border-[oklch(0.65_0.28_330/0.8)] bg-[oklch(0.65_0.28_330/0.06)]"
                  : "border-border hover:border-[oklch(0.65_0.28_330/0.5)] hover:bg-[oklch(0.65_0.28_330/0.03)]"
              )}
            >
              <input {...getInputProps()} />
              <FileText
                className={cn(
                  "w-10 h-10 transition-colors",
                  isDragActive ? "neon-pink" : "text-muted-foreground"
                )}
              />
              <div className="text-center">
                <p className="text-sm font-['Rajdhani'] font-semibold text-foreground">
                  {isDragActive ? "Release to parse file" : "Drop your text file here"}
                </p>
                <p className="text-xs font-mono text-muted-foreground mt-1">
                  or click to browse — .txt, .md, .csv
                </p>
              </div>
            </div>

            {/* Example format */}
            <div className="bg-muted/30 border border-border rounded-sm p-3">
              <p className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mb-2">
                Supported formats
              </p>
              <pre className="text-[11px] font-mono text-muted-foreground leading-relaxed">
{`1. Research competitor pricing
2. Write project proposal
3) Schedule team meeting
- Update documentation
• Review pull requests
Plain line without prefix`}
              </pre>
            </div>
          </div>
        )}

        {/* ── Step: Preview ── */}
        {step === "preview" && (
          <div className="flex flex-col gap-3 mt-2 min-h-0 flex-1 overflow-hidden">
            {/* File info + options */}
            <div className="flex items-start gap-4 flex-shrink-0 flex-wrap">
              <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
                <FileText className="w-3.5 h-3.5" />
                <span className="text-foreground font-semibold">{fileName}</span>
                <span>·</span>
                <span className="neon-pink">{parsedTitles.length}</span>
                <span>lines parsed</span>
              </div>
            </div>

            {/* Priority + Parent + Tags row */}
            <div className="flex items-center gap-3 flex-shrink-0 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">
                  Priority:
                </span>
                <Select value={priority} onValueChange={(v) => setPriority(v as TaskPriority)}>
                  <SelectTrigger className="h-7 w-28 bg-input border-border text-xs font-mono">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="low" className="text-xs font-mono">Low</SelectItem>
                    <SelectItem value="medium" className="text-xs font-mono">Medium</SelectItem>
                    <SelectItem value="high" className="text-xs font-mono">High</SelectItem>
                    <SelectItem value="urgent" className="text-xs font-mono">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest whitespace-nowrap">
                  Parent:
                </span>
                <Select value={parentId} onValueChange={setParentId}>
                  <SelectTrigger className="h-7 w-44 bg-input border-border text-xs font-mono">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border max-h-48">
                    <SelectItem value="none" className="text-xs font-mono">Top-level (no parent)</SelectItem>
                    {allTasks
                      .filter((t) => t.parentId === null)
                      .map((t) => (
                        <SelectItem key={t.id} value={String(t.id)} className="text-xs font-mono">
                          {t.title.length > 32 ? t.title.slice(0, 32) + "…" : t.title}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest whitespace-nowrap">
                  Tags:
                </span>
                <Input
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  placeholder="Add tag..."
                  className="bg-input border-border font-mono text-xs h-7"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      const t = tagInput.trim().toLowerCase();
                      if (t && !tags.includes(t)) setTags([...tags, t]);
                      setTagInput("");
                    }
                  }}
                />
                {tags.map((t) => (
                  <span
                    key={t}
                    className="flex items-center gap-1 px-1.5 py-0.5 bg-[oklch(0.65_0.28_330/0.1)] border border-[oklch(0.65_0.28_330/0.3)] text-[oklch(0.65_0.28_330)] text-[9px] font-mono rounded-sm whitespace-nowrap"
                  >
                    {t}
                    <button onClick={() => setTags(tags.filter((x) => x !== t))}>
                      <X className="w-2 h-2" />
                    </button>
                  </span>
                ))}
              </div>
            </div>

            {/* Instruction */}
            <p className="text-[10px] font-mono text-muted-foreground flex-shrink-0">
              Click a task title to edit it inline. Click{" "}
              <X className="w-2.5 h-2.5 inline" /> to exclude it from import.{" "}
              <span className="neon-cyan">{activeCount}</span> of {parsedTitles.length} will be imported.
            </p>

            {/* Task preview list — virtualized-style scroll */}
            <div className="flex-1 overflow-y-auto space-y-0.5 min-h-0 pr-1 border border-border rounded-sm p-1">
              {editedTitles.map((title, i) => {
                const removed = removedIndices.has(i);
                return (
                  <div
                    key={i}
                    className={cn(
                      "flex items-center gap-2 px-2 py-1 border rounded-sm transition-all duration-100",
                      removed
                        ? "border-transparent bg-muted/10 opacity-40"
                        : "border-transparent bg-muted/20 hover:border-[oklch(0.78_0.22_195/0.3)]"
                    )}
                  >
                    <span className="text-[9px] font-mono text-muted-foreground w-7 flex-shrink-0 text-right">
                      {i + 1}.
                    </span>
                    <input
                      value={title}
                      onChange={(e) => {
                        const next = [...editedTitles];
                        next[i] = e.target.value;
                        setEditedTitles(next);
                      }}
                      disabled={removed}
                      className={cn(
                        "flex-1 bg-transparent text-xs font-['Rajdhani'] font-medium text-foreground focus:outline-none min-w-0",
                        removed && "line-through text-muted-foreground"
                      )}
                    />
                    <button
                      onClick={() => toggleRemove(i)}
                      className={cn(
                        "flex-shrink-0 p-0.5 transition-colors",
                        removed
                          ? "text-[oklch(0.75_0.22_145)] hover:text-foreground"
                          : "text-muted-foreground hover:text-destructive"
                      )}
                      title={removed ? "Restore" : "Exclude"}
                    >
                      {removed ? (
                        <CheckCircle2 className="w-3 h-3" />
                      ) : (
                        <X className="w-3 h-3" />
                      )}
                    </button>
                  </div>
                );
              })}
            </div>

            {/* Actions — always visible at bottom */}
            <div className="flex gap-3 pt-3 flex-shrink-0 border-t border-border">
              <Button
                variant="outline"
                className="border-border text-xs font-mono tracking-widest uppercase"
                onClick={handleReset}
              >
                Back
              </Button>
              <Button
                className="flex-1 btn-neon-cyan bg-[oklch(0.78_0.22_195/0.1)] border border-[oklch(0.78_0.22_195/0.5)] text-[oklch(0.78_0.22_195)] hover:bg-[oklch(0.78_0.22_195/0.2)] text-xs font-['Orbitron'] tracking-widest uppercase"
                onClick={handleImport}
                disabled={bulkCreateMutation.isPending || activeCount === 0}
              >
                {bulkCreateMutation.isPending ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                    Importing...
                  </>
                ) : (
                  <>
                    <Zap className="w-3.5 h-3.5 mr-1.5" />
                    Import {activeCount} Task{activeCount !== 1 ? "s" : ""}
                  </>
                )}
              </Button>
            </div>
          </div>
        )}

        {/* ── Step: Done ── */}
        {step === "done" && (
          <div className="flex flex-col items-center gap-6 py-8 mt-2">
            <CheckCircle2 className="w-14 h-14 text-[oklch(0.75_0.22_145)] drop-shadow-[0_0_12px_oklch(0.75_0.22_145/0.6)]" />
            <div className="text-center">
              <p className="font-['Orbitron'] text-base font-bold text-[oklch(0.75_0.22_145)] tracking-widest uppercase">
                Import Complete
              </p>
              <p className="text-sm font-mono text-muted-foreground mt-2">
                <span className="neon-cyan font-bold">{importedCount}</span> tasks created
                successfully
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="border-border text-xs font-mono tracking-widest uppercase"
                onClick={handleReset}
              >
                Import More
              </Button>
              <Button
                className="btn-neon-cyan bg-[oklch(0.78_0.22_195/0.1)] border border-[oklch(0.78_0.22_195/0.5)] text-[oklch(0.78_0.22_195)] hover:bg-[oklch(0.78_0.22_195/0.2)] text-xs font-['Orbitron'] tracking-widest uppercase"
                onClick={handleClose}
              >
                Done
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
