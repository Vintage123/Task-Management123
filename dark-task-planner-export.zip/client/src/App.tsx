import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import AppShell from "./components/AppShell";
import TasksPage from "./pages/TasksPage";
import IdeasPage from "./pages/IdeasPage";

function Router() {
  return (
    <AppShell>
      <Switch>
        <Route path={"/"} component={TasksPage} />
        <Route path={"/tasks"} component={TasksPage} />
        <Route path={"/ideas"} component={IdeasPage} />
        <Route path={"/404"} component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </AppShell>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster
            theme="dark"
            toastOptions={{
              style: {
                background: "oklch(0.10 0.015 270)",
                border: "1px solid oklch(0.22 0.04 270)",
                color: "oklch(0.95 0.02 200)",
              },
            }}
          />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
