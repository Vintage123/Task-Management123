import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  bigint,
} from "drizzle-orm/mysql-core";

// ─── Users ────────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Tasks ────────────────────────────────────────────────────────────────────
export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  parentId: int("parentId"), // null = top-level task
  title: varchar("title", { length: 512 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["todo", "in-progress", "done"]).default("todo").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium").notNull(),
  category: mysqlEnum("category", [
    "AI & Automation",
    "Data Scraping",
    "Reselling",
    "App Dev",
    "Learning",
    "Health",
    "Organization",
    "Shopping",
    "Travel",
    "Miscellaneous",
  ])
    .default("Miscellaneous")
    .notNull(),
  estimatedTime: varchar("estimatedTime", { length: 64 }), // e.g. "2h", "30 min", "Ongoing"
  estimatedMinutes: int("estimatedMinutes"), // normalized for calculations
  scheduledDate: timestamp("scheduledDate"), // calendar scheduling
  dueDate: timestamp("dueDate"),
  tags: text("tags"), // JSON array stored as string
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

// ─── Ideas ────────────────────────────────────────────────────────────────────
export const ideas = mysqlTable("ideas", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 512 }).notNull(),
  content: text("content"),
  status: mysqlEnum("status", [
    "brainstorm",
    "refined",
    "in-progress",
    "implemented",
    "archived",
  ])
    .default("brainstorm")
    .notNull(),
  tags: text("tags"), // JSON array stored as string
  convertedTaskId: int("convertedTaskId"), // set when promoted to task
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Idea = typeof ideas.$inferSelect;
export type InsertIdea = typeof ideas.$inferInsert;

// ─── Drawings ─────────────────────────────────────────────────────────────────
export const drawings = mysqlTable("drawings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  taskId: int("taskId").notNull(), // linked to a specific task
  name: varchar("name", { length: 256 }).default("Untitled Canvas").notNull(),
  data: text("data").notNull(), // Excalidraw JSON serialized as string
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Drawing = typeof drawings.$inferSelect;
export type InsertDrawing = typeof drawings.$inferInsert;

// ─── Files ────────────────────────────────────────────────────────────────────
export const files = mysqlTable("files", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  taskId: int("taskId").notNull(), // attached to a specific task
  name: varchar("name", { length: 512 }).notNull(),
  mimeType: varchar("mimeType", { length: 128 }).notNull(),
  size: bigint("size", { mode: "number" }).notNull(), // bytes
  storageKey: varchar("storageKey", { length: 1024 }).notNull(),
  storageUrl: varchar("storageUrl", { length: 2048 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type File = typeof files.$inferSelect;
export type InsertFile = typeof files.$inferInsert;
