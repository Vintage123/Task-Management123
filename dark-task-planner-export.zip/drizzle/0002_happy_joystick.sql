ALTER TABLE `tasks` ADD `category` enum('AI & Automation','Data Scraping','Reselling','App Dev','Learning','Health','Organization','Shopping','Travel','Miscellaneous') DEFAULT 'Miscellaneous' NOT NULL;--> statement-breakpoint
ALTER TABLE `tasks` ADD `estimatedTime` varchar(64);--> statement-breakpoint
ALTER TABLE `tasks` ADD `estimatedMinutes` int;--> statement-breakpoint
ALTER TABLE `tasks` ADD `scheduledDate` timestamp;